"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setStatus("loading");
    setMessage("");

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/newsletter/subscribe`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (res.ok) {
        setStatus("success");
        setMessage("✅ Confirmation email sent. Please check your inbox.");
        setEmail("");
      } else {
        setStatus("error");
        setMessage(data.message || "❌ Subscription failed.");
      }
    } catch (err) {
      console.error("Newsletter subscribe error:", err);
      setStatus("error");
      setMessage("❌ Server error. Please try again later.");
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex flex-col sm:flex-row justify-center items-center gap-4 max-w-xl mx-auto"
    >
      <input
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        className="w-full sm:w-auto px-4 py-3 rounded-md text-gray-900 placeholder-gray-400 bg-white/10 backdrop-blur-lg border border-white/20 focus:outline-none focus:ring-2 focus:ring-cyan-400"
      />
      <button
        type="submit"
        disabled={status === "loading"}
        className="px-6 py-3 font-semibold rounded-md text-white transition-transform hover:scale-105 disabled:opacity-60"
        style={{
          background: "linear-gradient(90deg, #22d3ee 0%, #3b82f6 100%)",
          boxShadow: "0 6px 16px rgba(34, 211, 238, 0.4)",
        }}
      >
        {status === "loading" ? "Subscribing..." : "Subscribe"}
      </button>

      {status !== "idle" && (
        <p
          className={`mt-2 sm:ml-4 text-sm ${
            status === "success" ? "text-green-400" : "text-red-400"
          }`}
        >
          {message}
        </p>
      )}
    </form>
  );
}
