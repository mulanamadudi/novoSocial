import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Quote,
  Code,
  CodeSquare,
  Link,
  Image,
  Video,
  Hash,
  Type,
  Palette,
  Undo,
  Redo,
  Eye,
  Save,
  Download,
  Upload,
  Maximize2,
  Minimize2,
  Sun,
  Moon,
  Settings,
  Search,
  Replace,
  FileText,
  Copy,
  Scissors,
  Clipboard,
} from "lucide-react";

type RichTextEditorProps = {
  value: string;
  onChange: (value: string) => void;
};

// const AdvancedBlogEditor = () => {
const AdvancedBlogEditor: React.FC<RichTextEditorProps> = ({
  value,
  onChange,
}) => {
  const [content, setContent] = useState(value);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [readingTime, setReadingTime] = useState(0);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkText, setLinkText] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [replaceTerm, setReplaceTerm] = useState("");
  const [showFindReplace, setShowFindReplace] = useState(false);

  // Active formatting states
  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    strikethrough: false,
    alignLeft: false,
    alignCenter: false,
    alignRight: false,
    alignJustify: false,
    unorderedList: false,
    orderedList: false,
    blockquote: false,
  });

  const [currentHeading, setCurrentHeading] = useState("");

  const editorRef = useRef(null);
  const fileInputRef = useRef(null);
  const [history, setHistory] = useState([""]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Color palette for text highlighting
  const colors = [
    "#ffffff",
    "#22d3ee",
    "#3b82f6",
    "#10b981",
    "#f59e0b",
    "#8b5cf6",
    "#ef4444",
    "#6b7280",
  ];

  // Initialize editor with empty content
  useEffect(() => {
    if (editorRef.current && !content) {
      editorRef.current.innerHTML = "";
    }
  }, []);

  useEffect(() => {
    setContent(value);
  }, [value]);

  // Update statistics
  useEffect(() => {
    const text = content.replace(/<[^>]*>/g, "");
    const words = text.split(/\s+/).filter((word) => word.length > 0);
    setWordCount(words.length);
    setCharCount(text.length);
    setReadingTime(Math.ceil(words.length / 200));
  }, [content]);

  // Check active formatting states
  const checkActiveFormats = useCallback(() => {
    if (!document.queryCommandSupported) return;

    try {
      setActiveFormats({
        bold: document.queryCommandState("bold"),
        italic: document.queryCommandState("italic"),
        underline: document.queryCommandState("underline"),
        strikethrough: document.queryCommandState("strikeThrough"),
        alignLeft: document.queryCommandState("justifyLeft"),
        alignCenter: document.queryCommandState("justifyCenter"),
        alignRight: document.queryCommandState("justifyRight"),
        alignJustify: document.queryCommandState("justifyFull"),
        unorderedList: document.queryCommandState("insertUnorderedList"),
        orderedList: document.queryCommandState("insertOrderedList"),
        blockquote: false, // Will be handled separately
      });

      // Check current heading
      const selection = window.getSelection();
      if (selection.rangeCount > 0) {
        let element = selection.anchorNode;
        if (element.nodeType === Node.TEXT_NODE) {
          element = element.parentElement;
        }

        while (element && element !== editorRef.current) {
          const tagName = element.tagName?.toLowerCase();
          if (["h1", "h2", "h3", "h4"].includes(tagName)) {
            setCurrentHeading(tagName);
            return;
          }
          if (tagName === "blockquote") {
            setActiveFormats((prev) => ({ ...prev, blockquote: true }));
          }
          element = element.parentElement;
        }
        setCurrentHeading("");
      }
    } catch (error) {
      console.log("Query command not supported");
    }
  }, []);

  // History management
  const saveToHistory = useCallback(
    (newContent) => {
      setHistory((prev) => {
        const newHistory = prev.slice(0, historyIndex + 1);
        newHistory.push(newContent);
        return newHistory;
      });
      setHistoryIndex((prev) => prev + 1);
    },
    [historyIndex]
  );

  const undo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const previousContent = history[newIndex];
      setHistoryIndex(newIndex);
      setContent(previousContent);
      onChange(previousContent);

      if (editorRef.current) {
        editorRef.current.innerHTML = previousContent;
      }
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const nextContent = history[newIndex];
      setHistoryIndex(newIndex);
      setContent(nextContent);
      if (editorRef.current) {
        editorRef.current.innerHTML = nextContent;
      }
    }
  };

  // Format commands with proper styling
  const formatText = (command, value = null) => {
    editorRef.current?.focus();

    try {
      if (command === "formatBlock" && value) {
        // Handle headings and blockquotes with proper styling
        document.execCommand(command, false, value);

        // Apply CSS styles to make formatting visible in editor
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
          let element = selection.anchorNode;
          if (element.nodeType === Node.TEXT_NODE) {
            element = element.parentElement;
          }

          // Find the formatted element
          while (element && element !== editorRef.current) {
            const tagName = element.tagName?.toLowerCase();
            if (tagName === value.toLowerCase()) {
              // Apply inline styles for visual feedback
              switch (value) {
                case "h1":
                  element.style.fontSize = "2em";
                  element.style.fontWeight = "bold";
                  element.style.marginTop = "0.67em";
                  element.style.marginBottom = "0.67em";
                  element.style.color = "#22d3ee";
                  break;
                case "h2":
                  element.style.fontSize = "1.5em";
                  element.style.fontWeight = "bold";
                  element.style.marginTop = "0.83em";
                  element.style.marginBottom = "0.83em";
                  element.style.color = "#3b82f6";
                  break;
                case "h3":
                  element.style.fontSize = "1.17em";
                  element.style.fontWeight = "bold";
                  element.style.marginTop = "1em";
                  element.style.marginBottom = "1em";
                  element.style.color = "#06b6d4";
                  break;
                case "h4":
                  element.style.fontSize = "1em";
                  element.style.fontWeight = "bold";
                  element.style.marginTop = "1.33em";
                  element.style.marginBottom = "1.33em";
                  element.style.color = "#0ea5e9";
                  break;
                case "blockquote":
                  element.style.marginLeft = "20px";
                  element.style.marginRight = "20px";
                  element.style.fontStyle = "italic";
                  element.style.borderLeft = "4px solid #22d3ee";
                  element.style.paddingLeft = "16px";
                  element.style.color = "#94a3b8";
                  element.style.backgroundColor = "rgba(34, 211, 238, 0.05)";
                  element.style.borderRadius = "0 8px 8px 0";
                  element.style.padding = "12px 16px";
                  break;
              }
              break;
            }
            element = element.parentElement;
          }
        }
      } else {
        document.execCommand(command, false, value);
      }

      const newContent = editorRef.current.innerHTML;
      setContent(newContent);
      onChange(newContent);

      saveToHistory(newContent);

      // Update active states after a short delay
      setTimeout(checkActiveFormats, 50);
    } catch (error) {
      console.error("Format command failed:", error);
    }
  };

  // Handle content changes
  const handleContentChange = () => {
    if (editorRef.current) {
      const newContent = editorRef.current.innerHTML;
      setContent(newContent);
      onChange(newContent);

      saveToHistory(newContent);
      checkActiveFormats();
    }
  };

  // Handle image upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = `<img src="${e.target.result}" alt="Uploaded image" style="max-width: 100%; height: auto; border-radius: 12px; margin: 16px 0; border: 1px solid #334155;" />`;
        document.execCommand("insertHTML", false, img);
        handleContentChange();
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle link insertion
  const insertLink = () => {
    if (linkUrl && linkText) {
      const link = `<a href="${linkUrl}" style="color: #22d3ee; text-decoration: underline; font-weight: 500;">${linkText}</a>`;
      document.execCommand("insertHTML", false, link);
      handleContentChange();
      setShowLinkDialog(false);
      setLinkUrl("");
      setLinkText("");
    }
  };

  // Find and replace functionality
  const findAndReplace = () => {
    if (searchTerm && replaceTerm) {
      const newContent = content.replaceAll(searchTerm, replaceTerm);
      setContent(newContent);
      onChange(newContent);

      if (editorRef.current) {
        editorRef.current.innerHTML = newContent;
      }
      saveToHistory(newContent);
    }
  };

  // Export content
  const exportContent = () => {
    const blob = new Blob([content], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "blog-post.html";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Button component with active state styling
  const ToolbarButton = ({
    onClick,
    isActive,
    title,
    children,
    disabled = false,
  }) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`p-2 rounded-lg transition-all duration-200 ${
        isActive
          ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 scale-105"
          : disabled
          ? "text-slate-500 cursor-not-allowed opacity-50"
          : "text-slate-300 hover:text-white hover:bg-slate-700 hover:shadow-md hover:scale-105"
      }`}
      title={title}
    >
      {children}
    </button>
  );

  return (
    <div
      className={`${
        isFullscreen ? "fixed inset-0 z-50" : "w-full"
      } bg-slate-900 text-white transition-all duration-300`}
    >
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700 bg-slate-800 rounded-t-2xl">
          <div className="flex items-center gap-4">
            <FileText className="h-6 w-6 text-cyan-400" />
            <h1 className="text-lg font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Advanced Blog Editor
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <ToolbarButton
              onClick={() => setShowFindReplace(!showFindReplace)}
              title="Find & Replace"
            >
              <Search size={18} />
            </ToolbarButton>
            <ToolbarButton
              onClick={() => setShowPreview(!showPreview)}
              isActive={showPreview}
              title="Toggle Preview"
            >
              <Eye size={18} />
            </ToolbarButton>
            <ToolbarButton
              onClick={() => setIsFullscreen(!isFullscreen)}
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </ToolbarButton>
          </div>
        </div>

        {/* Find & Replace Panel */}
        {showFindReplace && (
          <div className="p-4 border-b border-slate-700 bg-slate-800">
            <div className="flex gap-4 items-center">
              <input
                type="text"
                placeholder="Find..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-3 py-2 border border-slate-700 rounded-xl flex-1 bg-slate-900 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
              />
              <input
                type="text"
                placeholder="Replace with..."
                value={replaceTerm}
                onChange={(e) => setReplaceTerm(e.target.value)}
                className="px-3 py-2 border border-slate-700 rounded-xl flex-1 bg-slate-900 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
              />
              <button
                onClick={findAndReplace}
                className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all duration-200 font-medium hover:shadow-lg"
              >
                Replace All
              </button>
            </div>
          </div>
        )}

        {/* Toolbar */}
        <div className="p-4 border-b border-slate-700 bg-slate-800">
          <div className="flex flex-wrap gap-3">
            {/* File Operations */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={() => {
                  setContent("");
                  if (editorRef.current) {
                    editorRef.current.innerHTML = "";
                  }
                  setHistory([""]);
                  setHistoryIndex(0);
                }}
                title="New Document"
              >
                <FileText size={16} />
              </ToolbarButton>
              <ToolbarButton onClick={exportContent} title="Export">
                <Download size={16} />
              </ToolbarButton>
            </div>

            {/* History */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={undo}
                disabled={historyIndex <= 0}
                title="Undo"
              >
                <Undo size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={redo}
                disabled={historyIndex >= history.length - 1}
                title="Redo"
              >
                <Redo size={16} />
              </ToolbarButton>
            </div>

            {/* Text Formatting */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={() => formatText("bold")}
                isActive={activeFormats.bold}
                title="Bold"
              >
                <Bold size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("italic")}
                isActive={activeFormats.italic}
                title="Italic"
              >
                <Italic size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("underline")}
                isActive={activeFormats.underline}
                title="Underline"
              >
                <Underline size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("strikeThrough")}
                isActive={activeFormats.strikethrough}
                title="Strikethrough"
              >
                <Strikethrough size={16} />
              </ToolbarButton>
            </div>

            {/* Headings */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    formatText("formatBlock", e.target.value);
                  }
                }}
                value={currentHeading}
                className="p-2 rounded-lg border-0 bg-slate-600 text-sm font-medium text-slate-200 focus:text-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
              >
                <option value="">Normal</option>
                <option value="h1">Heading 1</option>
                <option value="h2">Heading 2</option>
                <option value="h3">Heading 3</option>
                <option value="h4">Heading 4</option>
              </select>
            </div>

            {/* Alignment */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={() => formatText("justifyLeft")}
                isActive={activeFormats.alignLeft}
                title="Align Left"
              >
                <AlignLeft size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("justifyCenter")}
                isActive={activeFormats.alignCenter}
                title="Align Center"
              >
                <AlignCenter size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("justifyRight")}
                isActive={activeFormats.alignRight}
                title="Align Right"
              >
                <AlignRight size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("justifyFull")}
                isActive={activeFormats.alignJustify}
                title="Justify"
              >
                <AlignJustify size={16} />
              </ToolbarButton>
            </div>

            {/* Lists and Quotes */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={() => formatText("insertUnorderedList")}
                isActive={activeFormats.unorderedList}
                title="Bullet List"
              >
                <List size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("insertOrderedList")}
                isActive={activeFormats.orderedList}
                title="Numbered List"
              >
                <ListOrdered size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => formatText("formatBlock", "blockquote")}
                isActive={activeFormats.blockquote}
                title="Quote"
              >
                <Quote size={16} />
              </ToolbarButton>
            </div>

            {/* Media and Links */}
            <div className="flex items-center gap-1 p-2 bg-slate-700 rounded-xl border border-slate-600">
              <ToolbarButton
                onClick={() => setShowLinkDialog(true)}
                title="Insert Link"
              >
                <Link size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() => fileInputRef.current?.click()}
                title="Insert Image"
              >
                <Image size={16} />
              </ToolbarButton>
              <ToolbarButton
                onClick={() =>
                  formatText(
                    "insertHTML",
                    '<hr style="margin: 20px 0; border: 2px solid #22d3ee; border-radius: 2px; background: linear-gradient(90deg, #22d3ee, #3b82f6);">'
                  )
                }
                title="Insert Divider"
              >
                <span className="text-xs font-bold">──</span>
              </ToolbarButton>
            </div>

            {/* Colors */}
            <div className="relative">
              <ToolbarButton
                onClick={() => setShowColorPicker(!showColorPicker)}
                isActive={showColorPicker}
                title="Text Color"
              >
                <Palette size={16} />
              </ToolbarButton>
              {showColorPicker && (
                <div className="absolute top-full left-0 mt-2 p-3 bg-slate-800 border border-slate-600 rounded-xl shadow-xl z-10">
                  <div className="grid grid-cols-4 gap-2">
                    {colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => {
                          formatText("foreColor", color);
                          setShowColorPicker(false);
                        }}
                        className="w-8 h-8 rounded-lg border-2 border-slate-600 hover:border-cyan-400 transition-all duration-200 hover:scale-110"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Editor/Preview Area */}
        <div className="flex-1 flex overflow-hidden bg-slate-800">
          {!showPreview ? (
            <div
              ref={editorRef}
              contentEditable
              onInput={handleContentChange}
              onKeyUp={checkActiveFormats}
              onMouseUp={checkActiveFormats}
              className="flex-1 p-6 focus:outline-none overflow-y-auto bg-slate-900 text-white border border-slate-700 rounded-xl m-4"
              style={{
                minHeight: "400px",
                lineHeight: "1.7",
                fontSize: "16px",
                fontFamily:
                  '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
              }}
              suppressContentEditableWarning={true}
              placeholder="Start writing your amazing blog post here..."
            />
          ) : (
            <div className="flex-1 p-6 overflow-y-auto bg-slate-900 border border-slate-700 rounded-xl m-4">
              <div
                className="prose prose-invert max-w-none prose-headings:text-cyan-400 prose-a:text-cyan-400 prose-code:text-cyan-300 prose-blockquote:border-cyan-400"
                dangerouslySetInnerHTML={{
                  __html:
                    content ||
                    '<p class="text-slate-500">Start writing to see preview...</p>',
                }}
              />
            </div>
          )}
        </div>

        {/* Status Bar */}
        <div className="px-6 py-4 border-t border-slate-700 bg-slate-800 rounded-b-2xl">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-6 text-sm text-slate-400">
              <span className="flex items-center gap-2">
                <Type className="h-4 w-4 text-cyan-400" />
                <strong className="text-white">{wordCount}</strong> words
              </span>
              <span>{charCount} characters</span>
              <span>~{readingTime} min read</span>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <span className="flex items-center gap-2 text-cyan-400">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                Ready
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />

      {/* Link Dialog */}
      {showLinkDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="p-6 rounded-2xl bg-slate-800 border border-slate-600 w-96 shadow-2xl">
            <h3 className="text-lg font-semibold mb-4 text-white bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Insert Link
            </h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Link text"
                value={linkText}
                onChange={(e) => setLinkText(e.target.value)}
                className="w-full px-3 py-2 border border-slate-700 rounded-xl bg-slate-900 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
              />
              <input
                type="url"
                placeholder="https://example.com"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                className="w-full px-3 py-2 border border-slate-700 rounded-xl bg-slate-900 text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
              />
              <div className="flex gap-3">
                <button
                  onClick={insertLink}
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all duration-200 font-medium hover:shadow-lg"
                >
                  Insert Link
                </button>
                <button
                  onClick={() => setShowLinkDialog(false)}
                  className="flex-1 px-4 py-2 border border-slate-600 rounded-xl hover:bg-slate-700 transition-colors text-slate-300"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedBlogEditor;
