"use client";

import { useRouter } from "next/navigation";
import axios from "axios";
import {
  MdDashboard,
  MdPersonAdd,
  MdPeople,
  MdPostAdd,
  MdList,
  MdCategory,
  MdMailOutline,
  MdMarkEmailRead,
  MdLogout,
  MdMenu,
} from "react-icons/md";
import { useState } from "react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isSuperAdmin: boolean;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  isSuperAdmin,
}: SidebarProps) {
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = async () => {
    try {
      await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/auth/logout`, {
        withCredentials: true,
      });
      router.push("/admin");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  // Define tabs with visibility based on isSuperAdmin
  const tabs = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: <MdDashboard />,
      show: isSuperAdmin,
    },
    {
      id: "create-admin",
      label: "Create Admin",
      icon: <MdPersonAdd />,
      show: isSuperAdmin,
    },
    {
      id: "list-admins",
      label: "List Admins",
      icon: <MdPeople />,
      show: isSuperAdmin,
    },
    {
      id: "create-blog",
      label: "Create Blog",
      icon: <MdPostAdd />,
      show: true,
    },
    {
      id: "create-category",
      label: "Categories",
      icon: <MdCategory />,
      show: isSuperAdmin,
    },
    {
      id: "list-blogs",
      label: "List Blogs",
      icon: <MdList />,
      show: isSuperAdmin,
    },
    {
      id: "contact-forms",
      label: "Contact Forms",
      icon: <MdMailOutline />,
      show: isSuperAdmin,
    },
    {
      id: "newsletter",
      label: "Newsletter",
      icon: <MdMarkEmailRead />,
      show: isSuperAdmin,
    },
  ];

  return (
    <aside
      className={`bg-[#1e293b] ${
        collapsed ? "w-20" : "w-64"
      } min-h-screen text-white flex flex-col transition-all duration-300 p-4`}
    >
      <div>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-white mb-6 flex items-center gap-2 px-2 py-1 hover:bg-white/10 rounded"
        >
          <MdMenu className="text-2xl" />
          {!collapsed && <span className="text-xl font-bold">Admin Panel</span>}
        </button>

        <nav className="space-y-2 flex flex-col">
          {tabs.map(
            (tab) =>
              tab.show && (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-3 w-full text-left px-4 py-2 rounded-md transition-all ${
                    activeTab === tab.id
                      ? "bg-cyan-600 font-semibold"
                      : "hover:bg-white/10"
                  }`}
                >
                  {tab.icon}
                  {!collapsed && <span>{tab.label}</span>}
                </button>
              )
          )}
        </nav>
      </div>

      <div className="mt-auto pt-6 border-t border-white/10">
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 w-full bg-red-500 text-white rounded-md hover:bg-red-600"
        >
          <MdLogout />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}
