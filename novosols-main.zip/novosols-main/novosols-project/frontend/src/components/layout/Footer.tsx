"use client";
import Link from "next/link";
import Image from "next/image";
import React from "react";
import {
  Sparkles,
  Mail,
  Globe,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  ArrowRight,
  MapPin,
  Phone,
} from "lucide-react";

interface FooterLink {
  href: string;
  label: string;
}

interface FooterSection {
  title: string;
  links: FooterLink[];
}

export default function Footer(): JSX.Element {
  const productLinks: FooterLink[] = [
    { href: "/services", label: "Digital Transformation" },
    { href: "/services", label: "Custom Software Development" },
    { href: "/services", label: "Enterprise Systems" },
    { href: "/services", label: "FinTech Solutions" },
    { href: "/services", label: "Healthcare IT Solutions" },
    { href: "/services", label: "IoT & Smart Systems" },
  ];

  const companyLinks: FooterLink[] = [
    { href: "/about", label: "About Us" },
    { href: "/services", label: "Services" },
    { href: "/portfolio", label: "Portfolio" },
    { href: "/contact", label: "Contact Us" },
    { href: "/blogs", label: "Blogs" },
    { href: "/privacy-policy", label: "Privacy Policy" },
  ];

  const XIcon = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );

  const socialLinks = [
    {
      href: "https://facebook.com/novosols",
      icon: <Facebook className="w-4 h-4" />,
      label: "Facebook",
    },
    {
      href: "https://x.com/novosols",
      icon: <XIcon className="w-4 h-4" />,
      label: "X",
    },
    {
      href: "https://www.instagram.com/novosols",
      icon: <Instagram className="w-4 h-4" />,
      label: "Instagram",
    },
    {
      href: "https://www.linkedin.com/company/novo-sols/",
      icon: <Linkedin className="w-4 h-4" />,
      label: "LinkedIn",
    },
    {
      href: "https://saimayaqub.substack.com/",
      icon: <Mail className="w-4 h-4" />,
      label: "Substack",
    },
  ];

  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-slate-900 text-white border-t border-slate-700/50">
      {/* Subtle Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-96 h-32 bg-gradient-to-r from-cyan-500/3 to-blue-500/3 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8 mb-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            {/* Logo */}
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg overflow-hidden">
                <Image
                  src="/logo/logo.png"
                  alt="NOVO SOLS Logo"
                  width={32}
                  height={32}
                  className="w-full h-full object-cover"
                />
              </div>
              <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                NOVO SOLS
              </h2>
            </div>

            {/* Description */}
            <p className="text-slate-400 text-sm leading-relaxed mb-4">
              Helping businesses unlock their potential through innovative IT
              solutions and digital transformation.
            </p>

            {/* Contact Info */}
            <div className="space-y-2 mb-4">
              <a
                href="mailto:info@novosols.com"
                className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors duration-300 text-sm"
              >
                <Mail className="w-4 h-4" />
                info@novosols.com
              </a>

              <a
                href="https://www.novosols.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors duration-300 text-sm"
              >
                <Globe className="w-4 h-4" />
                www.novosols.com
              </a>
            </div>

            {/* Social Links */}
            <div className="flex gap-2">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-slate-800/50 border border-slate-700/50 flex items-center justify-center hover:bg-cyan-500/10 hover:border-cyan-400/30 hover:text-cyan-400 transition-all duration-300 text-slate-400"
                  title={social.label}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Services</h3>
            <ul className="space-y-2">
              {productLinks.slice(0, 4).map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-slate-400 hover:text-cyan-400 transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Company</h3>
            <ul className="space-y-2">
              {companyLinks.slice(0, 4).map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-slate-400 hover:text-cyan-400 transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact CTA */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">
              Get Started
            </h3>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">
              Ready to transform your business? Let's discuss your project
              today.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 text-white font-medium px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all duration-300 text-sm"
            >
              Contact Us
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-slate-700/50 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            {/* Copyright */}
            <div className="text-slate-400 text-sm text-center md:text-left">
              © {currentYear}{" "}
              <span className="font-semibold text-cyan-400">Novo Sols</span>.
              All rights reserved.
            </div>

            {/* Legal Links */}
            <div className="flex items-center gap-6 text-sm">
              <Link
                href="/terms"
                className="text-slate-400 hover:text-cyan-400 transition-colors duration-300"
              >
                Terms
              </Link>
              <Link
                href="/privacy"
                className="text-slate-400 hover:text-cyan-400 transition-colors duration-300"
              >
                Privacy
              </Link>
              <Link
                href="/cookies"
                className="text-slate-400 hover:text-cyan-400 transition-colors duration-300"
              >
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
