"use client";

interface SortDropdownProps {
  selected: string;
  onSelect: (val: string) => void;
}

export default function SortDropdown({ selected, onSelect }: SortDropdownProps) {
  return (
    <select
      value={selected}
      onChange={(e) => onSelect(e.target.value)}
      className="bg-white/10 border border-white/20 text-white px-3 py-2 rounded-lg"
    >
      <option value="latest">Latest</option>
      <option value="oldest">Oldest</option>
    </select>
  );
}
