"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "sonner";

interface Category {
  _id: string;
  name: string;
}

interface Props {
  refreshTrigger?: number;
}

export default function ReadOnlyCategoryList({ refreshTrigger }: Props) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCategories = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_BASE}/categories`);
      const data = await res.json();
      setCategories(data);
    } catch (err) {
      console.error("Failed to fetch categories", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this category?")) return;

    try {
      await axios.delete(`${process.env.NEXT_PUBLIC_API_BASE}/categories/${id}`, {
        withCredentials: true,
      });
      toast.success("Category deleted successfully");
      fetchCategories();
    } catch (err: any) {
      const msg =
        err?.response?.data?.message || "Failed to delete category";
      toast.error(msg);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchCategories();
  }, [refreshTrigger]);

  return (
    <div className="text-white mt-6">
      <h3 className="text-xl font-semibold mb-2">
        All Categories ({categories.length})
      </h3>

      {loading ? (
        <p className="text-white/70">Loading categories...</p>
      ) : categories.length === 0 ? (
        <p className="text-white/70">No categories found.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm border border-white/10">
            <thead>
              <tr className="bg-white/10 text-left text-white">
                <th className="px-4 py-2">#</th>
                <th className="px-4 py-2">Category Name</th>
                <th className="px-4 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((cat, i) => (
                <tr key={cat._id} className="border-t border-white/10">
                  <td className="px-4 py-2">{i + 1}</td>
                  <td className="px-4 py-2">{cat.name}</td>
                  <td className="px-4 py-2 text-right">
                    <button
                      onClick={() => handleDelete(cat._id)}
                      className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white text-xs"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
