import Link from "next/link";

interface Blog {
  _id: string;
  title: string;
  excerpt?: string;
  slug: string;
  thumbnail?: string;
  readTime?: number;
  createdAt: string;
  author: {
    name: string;
  };
  category: {
    name: string;
  };
}

export default function BlogCard({ blog }: { blog: Blog }) {
  return (
    <div className="bg-white/5 border border-white/10 p-5 rounded-lg backdrop-blur-lg shadow-lg hover:scale-[1.02] transition-transform duration-300">
      <h2 className="text-xl font-semibold text-white mb-2">{blog.title}</h2>
      <p className="text-sm text-gray-300 mb-2">{blog.excerpt?.slice(0, 120)}...</p>
      <div className="text-xs text-gray-400 mb-2">
        {blog.readTime} min read · {new Date(blog.createdAt).toLocaleDateString()} · {blog.category?.name}
      </div>
      <Link
        href={`/blogs/${blog.slug}`}
        className="text-cyan-300 hover:underline text-sm"
      >
        Read More →
      </Link>
    </div>
  );
}
