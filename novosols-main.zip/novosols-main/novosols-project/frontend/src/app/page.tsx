"use client";

import React, { useState } from "react";
import {
  ChevronRight,
  Code,
  Smartphone,
  Globe,
  Star,
  Users,
  Zap,
  ArrowRight,
  Mail,
  Check,
  Play,
  TrendingUp,
  Shield,
  Award,
} from "lucide-react";

interface Stat {
  number: string;
  label: string;
  icon: React.ReactNode;
}

interface Service {
  icon: React.ReactNode;
  title: string;
  desc: string;
  features: string[];
}

interface Testimonial {
  name: string;
  role: string;
  company: string;
  text: string;
  rating: number;
}

const NewsletterForm: React.FC = () => {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = () => {
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
    setEmail("");
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter your email"
        className="flex-1 px-6 py-4 bg-slate-900/50 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-300 backdrop-blur-xl"
        required
      />
      <button
        onClick={handleSubmit}
        className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl hover:from-cyan-400 hover:to-blue-500 hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 flex items-center gap-2"
      >
        {isSubmitted ? <Check className="w-5 h-5" /> : <Mail className="w-5 h-5" />}
        {isSubmitted ? "Subscribed!" : "Subscribe"}
      </button>
    </div>
  );
};

export default function Home(): JSX.Element {
  const stats: Stat[] = [
    { number: "500+", label: "Projects Delivered", icon: <Award className="w-6 h-6" /> },
    { number: "98%", label: "Client Satisfaction", icon: <Star className="w-6 h-6" /> },
    { number: "10+", label: "Years Experience", icon: <TrendingUp className="w-6 h-6" /> },
    { number: "24/7", label: "Support", icon: <Shield className="w-6 h-6" /> },
  ];

  const services: Service[] = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Software Development",
      desc: "Custom software solutions built with cutting-edge technologies and industry best practices.",
      features: ["Custom Applications", "API Development", "Cloud Solutions"],
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Web Development",
      desc: "Responsive, high-converting websites with modern UI designs and optimized performance.",
      features: ["Responsive Design", "E-commerce", "CMS Integration"],
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "App Development",
      desc: "Native and cross-platform mobile applications with seamless user experiences.",
      features: ["iOS & Android", "Cross-platform", "App Store Optimization"],
    },
  ];

  const testimonials: Testimonial[] = [
    {
      name: "Zachary Chen",
      role: "Product Manager",
      company: "TechCorp",
      text: "Novosols delivered above and beyond our expectations. Their technical expertise and attention to detail resulted in a product that exceeded our initial vision.",
      rating: 5,
    },
    {
      name: "Olivia Rodriguez",
      role: "Operations Manager",
      company: "HealthTech Solutions",
      text: "Novosols created a clean, HIPAA-compliant portal that streamlined our patient management system and improved our operational efficiency significantly.",
      rating: 5,
    },
    {
      name: "Lena Morris",
      role: "Operations Director",
      company: "InnovateCo",
      text: "The automation solutions they built saved us hours every week and transformed our workflow processes completely.",
      rating: 5,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white overflow-hidden">
      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 py-20">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>

        {/* Grid Pattern Overlay */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
            backgroundSize: "40px 40px",
          }}
        ></div>

        <div className="relative z-10 max-w-6xl mx-auto">
          <h1 className="text-6xl sm:text-7xl lg:text-8xl font-bold mb-8 leading-tight">
            Empowering the
            <span className="block bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Smart Life
            </span>
          </h1>
          
          <p className="text-slate-300 text-xl sm:text-2xl max-w-4xl mx-auto mb-12 leading-relaxed">
            Smart home & IoT innovations shaping tomorrow's living spaces with cutting-edge technology solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button className="group px-10 py-5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl hover:from-cyan-400 hover:to-blue-500 hover:scale-105 hover:shadow-xl hover:shadow-cyan-500/25 transition-all duration-300 flex items-center justify-center gap-3">
              <span className="text-lg">Start Your Free Analysis</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
            <button className="px-10 py-5 bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 text-white font-semibold rounded-xl hover:bg-slate-800/40 hover:border-cyan-400/30 hover:scale-105 transition-all duration-300 flex items-center justify-center gap-3">
              <Play className="w-5 h-5" />
              <span className="text-lg">Schedule a Call</span>
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 px-6">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-800/50 via-slate-900/50 to-slate-800/50"></div>
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center group">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-2xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-white">{stat.icon}</span>
                </div>
                <h3 className="text-4xl lg:text-5xl font-bold text-white mb-2 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  {stat.number}
                </h3>
                <p className="text-slate-300 text-lg font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="relative py-24 px-6">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 right-20 w-72 h-72 bg-cyan-500/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Our Services
            </h2>
            <p className="text-slate-300 text-xl max-w-3xl mx-auto leading-relaxed">
              Comprehensive technology solutions designed to drive your business forward
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, i) => (
              <div key={i} className="group bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 p-10 rounded-2xl hover:bg-slate-800/40 hover:border-cyan-400/30 hover:scale-105 transition-all duration-300">
                <div className="text-cyan-400 mb-8 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="text-2xl lg:text-3xl font-bold text-white mb-6 group-hover:text-cyan-400 transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-slate-300 text-lg mb-8 leading-relaxed">
                  {service.desc}
                </p>
                <ul className="space-y-3">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-slate-300">
                      <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"></div>
                      <span className="font-medium">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="relative py-24 px-6">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-800/30 via-slate-900/30 to-slate-800/30"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Client Success Stories
            </h2>
            <p className="text-slate-300 text-xl max-w-3xl mx-auto leading-relaxed">
              Hear from our satisfied clients about their transformative experiences
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, i) => (
              <div key={i} className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 p-8 rounded-2xl hover:bg-slate-800/40 hover:border-cyan-400/30 hover:scale-105 transition-all duration-300">
                <div className="flex gap-1 mb-6">
                  {[...Array(testimonial.rating)].map((_, idx) => (
                    <Star key={idx} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-300 text-lg mb-8 leading-relaxed italic">
                  "{testimonial.text}"
                </p>
                <div className="border-t border-slate-700/50 pt-6">
                  <p className="text-cyan-300 font-bold text-lg">{testimonial.name}</p>
                  <p className="text-slate-400 mb-1">{testimonial.role}</p>
                  <p className="text-blue-400 font-medium">{testimonial.company}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="relative py-24 px-6">
        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/3 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-1/3 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-12">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Stay in the{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Loop
              </span>
            </h2>
            <p className="text-slate-300 text-xl mb-10 leading-relaxed max-w-2xl mx-auto">
              Subscribe to our newsletter and never miss an update on the latest technology trends and innovations.
            </p>
            <NewsletterForm />
          </div>
        </div>
      </section>
    </div>
  );
}