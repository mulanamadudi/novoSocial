"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  CheckCircle,
  ArrowRight,
  Sparkles,
  Zap,
  Shield,
  Smartphone,
  Database,
  CreditCard,
  Heart,
  Wifi,
  ShoppingCart,
  BarChart3,
  Lock,
} from "lucide-react";

export default function ServicesPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const serviceIcons = {
    "Digital Transformation": Zap,
    "Custom Software Development": Smartphone,
    "Enterprise Systems": Database,
    "FinTech Solutions": CreditCard,
    "Healthcare IT Solutions": Heart,
    "IoT & Smart Systems": Wifi,
    "E-Commerce Solutions": ShoppingCart,
    "Data Analytics & Reporting": BarChart3,
    "Information Security Services": Lock,
  };

  const services = [
    {
      title: "Digital Transformation",
      desc: "Accelerate performance and efficiency with Agile, DevOps, and automation.",
      points: [
        "Agile Transformation Programs",
        "DevOps Process Implementation",
        "Business Process Automation",
      ],
    },
    {
      title: "Custom Software Development",
      desc: "Deliver cutting-edge web, mobile, and SaaS platforms.",
      points: [
        "Web Application Development",
        "Mobile App Development (iOS & Android)",
        "SaaS Platforms and API Integrations",
      ],
    },
    {
      title: "Enterprise Systems",
      desc: "Customized CRM and ERP solutions for sectors like healthcare and FinTech.",
      points: [
        "CRM and ERP Customization",
        "Healthcare ERP Solutions",
        "FinTech ERP Modules",
      ],
    },
    {
      title: "FinTech Solutions",
      desc: "Secure digital wallets, tokenization, and payment integrations.",
      points: [
        "Digital Wallets and Tokenization",
        "Cardholder Device Management",
        "Payment Gateway Integrations",
      ],
    },
    {
      title: "Healthcare IT Solutions",
      desc: "HIPAA-compliant solutions for patient portals, EHR, and telehealth.",
      points: [
        "HIPAA-Compliant Patient Portals",
        "Electronic Health Records",
        "Secure Billing and Teleclinic Apps",
      ],
    },
    {
      title: "IoT & Smart Systems",
      desc: "Innovative smart tech from home automation to IoT security.",
      points: [
        "Smart Home Applications",
        "Solar Monitoring Dashboards",
        "IoT Security Solutions",
      ],
    },
    {
      title: "E-Commerce Solutions",
      desc: "Scalable online stores, payment gateways, and logistics systems.",
      points: [
        "Full-stack E-commerce Website Development",
        "Payment & Logistics Integrations",
      ],
    },
    {
      title: "Data Analytics & Reporting",
      desc: "Actionable dashboards and predictive analytics for growth.",
      points: [
        "Business Intelligence Dashboards",
        "Predictive Analytics & Data Mining",
      ],
    },
    {
      title: "Information Security Services",
      desc: "End-to-end security, risk compliance, and fraud detection.",
      points: [
        "PCI-DSS Compliance Solutions",
        "Fraud Detection & Monitoring",
        "ISO 27001 Gap Analysis",
      ],
    },
  ];

  return (
    <div className="pt-4 min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background - Matching Blog Page */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <div className="relative z-10 container mx-auto px-6 py-20 max-w-7xl">
        {/* Header Section - Matching Blog Page Style */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-full px-4 py-2 mb-8">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 text-sm font-medium">
              Our Services
            </span>
          </div>

          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
            Digital Solutions & Innovation
          </h1>

          <p className="text-xl text-slate-300 leading-relaxed max-w-3xl mx-auto">
            From scalable web applications to enterprise-grade systems, we
            deliver powerful digital solutions that drive growth and performance
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = serviceIcons[service.title];
            return (
              <div
                key={index}
                className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300 group hover:scale-105"
              >
                {/* Service Header */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <h2 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">
                    {service.title}
                  </h2>
                </div>

                {/* Service Description */}
                <p className="text-slate-300 leading-relaxed mb-6 group-hover:text-white transition-colors duration-300">
                  {service.desc}
                </p>

                {/* Service Points */}
                <div className="space-y-3 mb-8">
                  {service.points.map((point, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0 text-green-400" />
                      <span className="text-slate-300 group-hover:text-white transition-colors duration-300 text-sm">
                        {point}
                      </span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <Link href="/contact" passHref>
                  <button className="cursor-pointer w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 hover:from-cyan-500/20 hover:to-blue-500/20 text-cyan-400 border border-cyan-500/20 hover:border-cyan-400/40 rounded-xl transition-all duration-300 group-hover:scale-105 font-medium">
                    <span>Get Quote</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </Link>
              </div>
            );
          })}
        </div>

        {/* Call to Action Section */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-12 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Ready to Transform Your Business?
            </h2>

            <p className="text-xl text-slate-300 leading-relaxed mb-10">
              Let's discuss how{" "}
              <span className="font-semibold text-cyan-400">NOVO SOLS</span> can
              help you achieve your digital transformation goals. Our expert
              team is ready to deliver innovative solutions tailored to your
              unique business needs.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button className="group inline-flex items-center gap-3 px-10 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold rounded-2xl transition-all duration-300 hover:scale-105 text-lg shadow-lg shadow-cyan-500/25">
                <span>Start Your Project</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
              </button>

              <button className="group inline-flex items-center gap-3 px-10 py-4 bg-slate-800/50 border border-slate-600/50 hover:bg-slate-700/50 text-cyan-400 font-bold rounded-2xl transition-all duration-300 hover:scale-105 text-lg">
                <span>View Portfolio</span>
                <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Decorative Elements */}
        <div className="flex justify-center mt-16">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse delay-200"></div>
            <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse delay-400"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
