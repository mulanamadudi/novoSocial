// Optional file — not required if you're handling "/" in src/app/page.tsx
export default function Placeholder() {
  return null;
}

// "use client";

// import React, { useState, useEffect } from "react";
// import {
//   ChevronRight,
//   Code,
//   Smartphone,
//   Globe,
//   Star,
//   Users,
//   Zap,
//   ArrowRight,
//   Mail,
//   Check,
//   Play,
//   TrendingUp,
//   Shield,
//   Award,
// } from "lucide-react";

// interface Stat {
//   number: string;
//   label: string;
//   icon: React.ReactNode;
// }

// interface Service {
//   icon: React.ReactNode;
//   title: string;
//   desc: string;
//   features: string[];
// }

// interface Testimonial {
//   name: string;
//   role: string;
//   company: string;
//   text: string;
//   rating: number;
// }

// interface FloatingElementProps {
//   children: React.ReactNode;
//   delay?: number;
// }

// const FloatingElement: React.FC<FloatingElementProps> = ({ children, delay = 0 }) => (
//   <div
//     className="animate-pulse"
//     style={{
//       animation: `float 6s ease-in-out infinite`,
//       animationDelay: `${delay}s`,
//     }}
//   >
//     {children}
//     <style jsx>{`
//       @keyframes float {
//         0%, 100% {
//           transform: translateY(0px) rotate(0deg);
//         }
//         50% {
//           transform: translateY(-20px) rotate(2deg);
//         }
//       }
//     `}</style>
//   </div>
// );

// const NewsletterForm: React.FC = () => {
//   const [email, setEmail] = useState("");
//   const [isSubmitted, setIsSubmitted] = useState(false);

//   const handleSubmit = () => {
//     setIsSubmitted(true);
//     setTimeout(() => setIsSubmitted(false), 3000);
//     setEmail("");
//   };

//   return (
//     <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
//       <input
//         type="email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//         placeholder="Enter your email"
//         className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400/40 focus:shadow-[0_10px_25px_-5px_rgba(34,211,238,0.25)] transition-all duration-300 backdrop-blur-lg"
//         required
//       />
//       <button
//         onClick={handleSubmit}
//         className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 text-white font-semibold rounded-lg hover:scale-105 hover:shadow-[0_6px_16px_rgba(34,211,238,0.4)] transition-all duration-300 flex items-center gap-2"
//       >
//         {isSubmitted ? <Check className="w-4 h-4" /> : <Mail className="w-4 h-4" />}
//         {isSubmitted ? "Subscribed!" : "Subscribe"}
//       </button>
//     </div>
//   );
// };

// export default function Home(): JSX.Element {
//   const stats: Stat[] = [
//     { number: "500+", label: "Projects Delivered", icon: <Award className="w-6 h-6" /> },
//     { number: "98%", label: "Client Satisfaction", icon: <Star className="w-6 h-6" /> },
//     { number: "10+", label: "Years Experience", icon: <TrendingUp className="w-6 h-6" /> },
//     { number: "24/7", label: "Support", icon: <Shield className="w-6 h-6" /> },
//   ];

//   const services: Service[] = [
//     {
//       icon: <Code className="w-8 h-8" />,
//       title: "Software Development",
//       desc: "Custom software solutions built with cutting-edge technologies.",
//       features: ["Custom Applications", "API Development", "Cloud Solutions"],
//     },
//     {
//       icon: <Globe className="w-8 h-8" />,
//       title: "Web Development",
//       desc: "Responsive, high-converting websites with interactive UI designs.",
//       features: ["Responsive Design", "E-commerce", "CMS Integration"],
//     },
//     {
//       icon: <Smartphone className="w-8 h-8" />,
//       title: "App Development",
//       desc: "Native and cross-platform mobile applications.",
//       features: ["iOS & Android", "Cross-platform", "App Store Optimization"],
//     },
//   ];

//   const testimonials: Testimonial[] = [
//     {
//       name: "Zachary Chen",
//       role: "Product Manager",
//       company: "TechCorp",
//       text: "Novosols delivered above and beyond.",
//       rating: 5,
//     },
//     {
//       name: "Olivia Rodriguez",
//       role: "Operations Manager",
//       company: "HealthTech Solutions",
//       text: "Novosols created a clean, HIPAA-compliant portal.",
//       rating: 5,
//     },
//     {
//       name: "Lena Morris",
//       role: "Operations Director",
//       company: "InnovateCo",
//       text: "Saved us hours every week with automation.",
//       rating: 5,
//     },
//   ];

//   return (
//     <div className="text-white overflow-hidden">
//       <section id="hero" className="min-h-screen flex flex-col items-center justify-center text-center px-6 py-20 bg-gradient-to-br from-blue-900 via-slate-900 to-blue-900">
//         <FloatingElement delay={0}>
//           <h1 className="text-5xl sm:text-6xl font-bold mb-6 leading-tight">
//             Empowering the
//             <span className="block bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
//               Smart Life
//             </span>
//           </h1>
//         </FloatingElement>
//         <FloatingElement delay={0.5}>
//           <p className="text-gray-300 text-lg sm:text-xl max-w-3xl mb-8">
//             Smart home & IoT innovations shaping tomorrow's living spaces.
//           </p>
//         </FloatingElement>
//         <FloatingElement delay={1}>
//           <div className="flex flex-col sm:flex-row gap-4 justify-center">
//             <button className="px-8 py-4 bg-gradient-to-r from-cyan-400 to-blue-500 text-white font-semibold rounded-lg hover:scale-105">
//               Start Your Free Analysis
//             </button>
//             <button className="px-8 py-4 bg-white/5 border border-white/10 text-white font-semibold rounded-lg hover:bg-white/10">
//               Schedule a Call
//             </button>
//           </div>
//         </FloatingElement>
//       </section>

//       <section className="py-16 px-6 bg-slate-900">
//         <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
//           {stats.map((stat, i) => (
//             <FloatingElement key={i} delay={i * 0.2}>
//               <div className="text-center">
//                 <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg mb-4">
//                   {stat.icon}
//                 </div>
//                 <h3 className="text-3xl font-bold text-white mb-1">{stat.number}</h3>
//                 <p className="text-gray-300 text-sm">{stat.label}</p>
//               </div>
//             </FloatingElement>
//           ))}
//         </div>
//       </section>

//       <section className="py-20 px-6 bg-gradient-to-br from-blue-900 via-slate-900 to-blue-900">
//         <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
//           {services.map((service, i) => (
//             <FloatingElement key={i} delay={i * 0.2}>
//               <div className="bg-white/5 border border-white/10 p-8 rounded-2xl h-full hover:bg-white/10">
//                 <div className="text-cyan-400 mb-6">{service.icon}</div>
//                 <h3 className="text-2xl font-bold text-white mb-4">{service.title}</h3>
//                 <p className="text-gray-300 mb-6">{service.desc}</p>
//                 <ul className="space-y-2">
//                   {service.features.map((feature, idx) => (
//                     <li key={idx} className="flex items-center gap-2 text-sm text-gray-400">
//                       <Check className="w-4 h-4 text-green-400" />
//                       {feature}
//                     </li>
//                   ))}
//                 </ul>
//               </div>
//             </FloatingElement>
//           ))}
//         </div>
//       </section>

//       <section className="py-20 px-6 bg-slate-900">
//         <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
//           {testimonials.map((testimonial, i) => (
//             <FloatingElement key={i} delay={i * 0.3}>
//               <div className="bg-white/5 border border-white/10 p-8 rounded-2xl hover:bg-white/10">
//                 <div className="flex gap-1 mb-4">
//                   {[...Array(testimonial.rating)].map((_, idx) => (
//                     <Star key={idx} className="w-5 h-5 text-yellow-400 fill-current" />
//                   ))}
//                 </div>
//                 <p className="text-gray-300 mb-6 italic">"{testimonial.text}"</p>
//                 <div className="border-t border-white/10 pt-4">
//                   <p className="text-cyan-300 font-bold">{testimonial.name}</p>
//                   <p className="text-gray-400 text-sm">{testimonial.role}</p>
//                   <p className="text-blue-400 text-sm font-medium">{testimonial.company}</p>
//                 </div>
//               </div>
//             </FloatingElement>
//           ))}
//         </div>
//       </section>

//       <section className="py-20 px-6 bg-gradient-to-br from-blue-900 via-slate-900 to-blue-900">
//         <div className="max-w-2xl mx-auto text-center">
//           <h2 className="text-3xl font-bold mb-4">
//             Stay in the <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Loop</span>
//           </h2>
//           <p className="text-gray-400 mb-8">
//             Subscribe to our newsletter and never miss an update.
//           </p>
//           <NewsletterForm />
//         </div>
//       </section>
//     </div>
//   );
// }