"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";

// Mock data for demonstration - you'd replace this with your actual data import
const mockProject = {
  slug: "healthcare-erp-revamp",
  title: "Healthcare ERP System Revamp",
  client: "American Telephysicians",
  industry: "Healthcare Technology",
  domain: "EHR, Medical Billing, Telemedicine",
  platform: "Web-based Enterprise System",
  sections: {
    background: "Our client, a leading US-based telephysician service provider, was operating with a legacy healthcare ERP system that struggled to meet evolving compliance requirements and user expectations. The system lacked modern security protocols, had performance bottlenecks, and couldn't scale to support their growing patient base of over 50,000 active users.",
    challenges: [
      "Legacy system failing HIPAA compliance audits with critical security vulnerabilities",
      "Poor performance with 15+ second load times affecting patient care delivery",
      "Limited scalability causing system crashes during peak usage periods",
      "Outdated user interface leading to clinician workflow inefficiencies",
      "Integration gaps preventing seamless data flow between departments"
    ],
    solution: "NOVO SOLS implemented a comprehensive ERP modernization strategy, rebuilding the core platform with cloud-native architecture and implementing robust security frameworks. Our team focused on maintaining business continuity while delivering a scalable, compliant, and user-friendly solution that exceeded industry standards.",
    actions: [
      "Conducted comprehensive security audit and implemented HIPAA-compliant infrastructure",
      "Redesigned database architecture for improved performance and scalability",
      "Developed modern React-based frontend with intuitive clinician workflows",
      "Integrated advanced encryption and access control mechanisms",
      "Implemented comprehensive testing framework achieving 100% code coverage",
      "Delivered phased rollout with zero-downtime deployment strategy"
    ],
    outcome: [
      "Achieved full HIPAA and Meaningful Use Stage 3 compliance certification",
      "Reduced system response times by 85% (from 15+ seconds to under 2 seconds)",
      "Increased system uptime to 99.9% with improved disaster recovery capabilities",
      "Enhanced clinician productivity by 40% through streamlined workflows",
      "Successfully scaled to support 100,000+ concurrent users",
      "Implemented robust security framework with zero security incidents post-launch"
    ],
    conclusion: "The Healthcare ERP revamp project demonstrates NOVO SOLS' expertise in delivering mission-critical healthcare technology solutions. By focusing on compliance, performance, and user experience, we helped our client transform their operations while maintaining the highest standards of patient data security and care delivery excellence."
  }
};

export default function ProjectDetailPage({ params }: { params?: { slug: string } }) {
  // In real implementation, you'd find the project by slug
  const project = mockProject;
  const { title, client, industry, domain, platform, sections } = project;

  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background - Same as Blog Page */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay - Same as Blog Page */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <section className="relative z-10 container mx-auto px-6 py-20 max-w-4xl">
        {/* Back Link - Matching Blog Style */}
        <div className="mb-10">
          <Link
            href="/portfolio"
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-xl text-cyan-400 hover:text-white hover:bg-slate-800/40 transition-all duration-300 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Portfolio
          </Link>
        </div>

        {/* Title - Same Gradient Style as Blog */}
        <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
          {title}
        </h1>

        {/* Metadata - Using Blog Card Style */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 mb-12">
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-cyan-400 font-semibold">Client:</span>
              <span className="text-slate-300 ml-2">{client}</span>
            </div>
            <div>
              <span className="text-cyan-400 font-semibold">Industry:</span>
              <span className="text-slate-300 ml-2">{industry}</span>
            </div>
            <div className="md:col-span-2">
              <span className="text-cyan-400 font-semibold">Domain:</span>
              <span className="text-slate-300 ml-2">{domain}</span>
            </div>
            <div className="md:col-span-2">
              <span className="text-cyan-400 font-semibold">Platform:</span>
              <span className="text-slate-300 ml-2">{platform}</span>
            </div>
          </div>
        </div>

        {/* Content Sections - Using Blog Card Style */}
        <div className="space-y-8">
          <DetailSection title="Background" content={sections.background} />
          <DetailListSection title="Challenges" items={sections.challenges} />
          <DetailSection title="Novo Sols' Solution" content={sections.solution} />
          <DetailListSection title="Key Actions" items={sections.actions} />
          <DetailListSection title="Outcome" items={sections.outcome} />
          <DetailSection title="Conclusion" content={sections.conclusion} />
        </div>

        {/* Call to Action - Matching Portfolio Page */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 mt-16 text-center">
          <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
            Ready to Transform Your Business?
          </h2>
          <p className="text-slate-300 mb-6 leading-relaxed">
            Let's discuss how NOVO SOLS can help you achieve similar results with a custom solution tailored to your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-medium rounded-xl transition-all duration-300 hover:scale-105">
              Start Your Project
            </button>
            <Link href="/portfolio" className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800/50 hover:bg-slate-700/50 text-cyan-400 font-medium rounded-xl transition-all duration-300 hover:scale-105 border border-slate-600/50 hover:border-cyan-400/50">
              View More Projects
            </Link>
          </div>
        </div>

        {/* Bottom Decorative Elements - Same as Blog */}
        <div className="flex justify-center mt-16">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-200"></div>
            <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse delay-400"></div>
          </div>
        </div>
      </section>
    </div>
  );
}

// COMPONENT: Standard Text Block - Matching Blog Card Style
function DetailSection({ title, content }: { title: string; content: string }) {
  return (
    <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300">
      <Heading title={title} />
      <p className="text-slate-300 text-lg leading-relaxed">{content}</p>
    </div>
  );
}

// COMPONENT: Bullet List Block - Matching Blog Card Style
function DetailListSection({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300">
      <Heading title={title} />
      <ul className="space-y-3">
        {items.map((item, i) => (
          <li key={i} className="flex items-start gap-3">
            <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full mt-2 flex-shrink-0"></div>
            <span className="text-slate-300 leading-relaxed">{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// COMPONENT: Heading With Line Accent - Matching Blog Style
function Heading({ title }: { title: string }) {
  return (
    <div className="mb-6">
      <h2 className="text-2xl font-bold text-cyan-400 mb-3">
        {title}
      </h2>
      <div className="w-16 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full" />
    </div>
  );
}