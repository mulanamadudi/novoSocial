"use client";

import { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  Sparkles, 
  Heart, 
  CreditCard, 
  ShoppingCart, 
  Wifi, 
  Users,
  Building2,
  ExternalLink,
  CheckCircle,
  TrendingUp
} from 'lucide-react';

export default function PortfolioPage() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredProject, setHoveredProject] = useState(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const portfolioProjects = [
    {
      slug: "healthcare-erp-revamp",
      title: "Healthcare ERP System Revamp",
      client: "American Telephysicians",
      shortDesc: "Compliance-focused revamp of a US healthcare ERP platform.",
      industry: "Healthcare Technology",
      domain: "EHR, Medical Billing, Telemedicine",
      platform: "Web-based Enterprise System",
      icon: Heart,
      gradient: "from-pink-500 to-violet-600",
      achievements: ["HIPAA & MU3 Compliant", "100% Test Coverage", "Enhanced Security"]
    },
    {
      slug: "agile-transformation-healthcare",
      title: "Agile Transformation for Healthcare Tech",
      client: "American Telephysicians",
      shortDesc: "Scrum-based transformation for delivery, QA, and collaboration improvements.",
      industry: "Healthcare Technology",
      domain: "Project Delivery & QA",
      platform: "Organizational Agile Framework",
      icon: TrendingUp,
      gradient: "from-emerald-500 to-cyan-500",
      achievements: ["50% Process Efficiency", "Faster Delivery", "Better Collaboration"]
    },
    {
      slug: "fintech-wallet-compliance",
      title: "FinTech Wallet Provisioning & Compliance",
      client: "Confidential",
      shortDesc: "PCI-DSS compliant mobile wallet with tokenization and fraud alerting.",
      industry: "FinTech & Digital Payments",
      domain: "Tokenized Wallets, Apple Pay, Fraud Protection",
      platform: "Mobile + API Integration",
      icon: CreditCard,
      gradient: "from-amber-500 to-red-500",
      achievements: ["PCI-DSS Compliant", "Apple Pay Integration", "Fraud Protection"]
    },
    {
      slug: "ecommerce-revamp",
      title: "E-Commerce Revamp for Voltech & PhotoLetterNames",
      client: "Voltech.com, PhotoLetterNames",
      shortDesc: "Modern e-commerce transformation for gifting and multi-category retail.",
      industry: "E-Commerce & Gifting",
      domain: "Retail, Personalization Platforms",
      platform: "Web-based Systems",
      icon: ShoppingCart,
      gradient: "from-violet-500 to-blue-500",
      achievements: ["Higher Conversions", "Streamlined Workflows", "Custom Personalization"]
    },
    {
      slug: "iot-energy-smart-home",
      title: "IoT Energy Monitoring & Smart Home Automation",
      client: "Invertlyzer & Home Users",
      shortDesc: "Smart energy dashboards and voice-controlled automation for 300+ clients.",
      industry: "Smart Energy & Home Automation",
      domain: "IoT, Security, BI Dashboards",
      platform: "IoT Devices + Web/Mobile Interfaces",
      icon: Wifi,
      gradient: "from-cyan-500 to-sky-400",
      achievements: ["300+ Clients", "Energy Savings", "Voice Control"]
    }
  ];

  const stats = [
    { label: "Successful Projects", value: "50+", icon: CheckCircle },
    { label: "Happy Clients", value: "30+", icon: Users },
    { label: "Industries Served", value: "8+", icon: Building2 },
    { label: "Years Experience", value: "10+", icon: TrendingUp }
  ];

  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background - Same as Blog Page */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay - Same as Blog Page */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <section className={`relative z-10 container mx-auto px-6 py-20 max-w-7xl transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        
        {/* Hero Section - Matching Blog Style */}
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
            Our Portfolio
          </h1>
          <p className="text-xl text-slate-300 leading-relaxed max-w-4xl mx-auto mb-8">
            Discover how <span className="font-semibold text-cyan-400">NOVO SOLS</span> has transformed businesses across industries through innovative digital solutions. From healthcare compliance to fintech security, our portfolio showcases real-world impact and measurable results.
          </p>
          <p className="text-lg text-cyan-400 font-medium">
            Proven success stories from startups to enterprise clients
          </p>
        </div>

        {/* Stats Section - Using Blog Page Glass Style */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <div key={index} 
                 className="group text-center p-6 bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl hover:bg-slate-800/40 transition-all duration-300 hover:scale-105">
              
              <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              
              <div className="text-3xl font-bold text-cyan-400 mb-2 group-hover:text-cyan-300 transition-colors duration-300">
                {stat.value}
              </div>
              
              <div className="text-sm text-slate-300 group-hover:text-white transition-colors duration-300">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Portfolio Grid - Matching Blog Card Style */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {portfolioProjects.map((project, index) => {
            const IconComponent = project.icon;
            return (
              <div key={project.slug}
                   className="group bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300 hover:scale-105 cursor-pointer overflow-hidden"
                   onMouseEnter={() => setHoveredProject(index)}
                   onMouseLeave={() => setHoveredProject(null)}>
                
                {/* Project Header */}
                <div className="flex items-center gap-3 mb-6">
                  <div className={`w-12 h-12 bg-gradient-to-r ${project.gradient} rounded-xl flex items-center justify-center`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300 line-clamp-2">
                      {project.title}
                    </h2>
                  </div>
                </div>
                
                {/* Client & Industry */}
                <div className="mb-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-cyan-400">Client:</span>
                    <span className="text-sm text-slate-300">{project.client}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-cyan-400">Industry:</span>
                    <span className="text-sm text-slate-300">{project.industry}</span>
                  </div>
                </div>
                
                {/* Description */}
                <p className="text-slate-300 group-hover:text-white transition-colors duration-300 mb-6 line-clamp-3">
                  {project.shortDesc}
                </p>
                
                {/* Key Achievements */}
                <div className="space-y-2 mb-6">
                  {project.achievements.map((achievement, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <span className="text-xs text-slate-300 group-hover:text-white transition-colors duration-300">
                        {achievement}
                      </span>
                    </div>
                  ))}
                </div>
                
                {/* Domain Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.domain.split(', ').slice(0, 2).map((tag, i) => (
                    <span key={i} 
                          className="px-3 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded-full text-xs font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
                
                {/* View Details Link - Same Button Style as Blog */}
                <a href={`/portfolio/${project.slug}`}
                   className="group/btn inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 hover:from-cyan-500/20 hover:to-blue-500/20 text-cyan-400 border border-cyan-500/20 hover:border-cyan-400/40 rounded-xl transition-all duration-300 hover:scale-105 w-full justify-center">
                  <span className="font-medium">View Details</span>
                  <ExternalLink className="w-4 h-4 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform duration-300" />
                </a>
              </div>
            );
          })}
        </div>

        {/* Call to Action Section - Matching Blog Glass Style */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-12 text-center hover:bg-slate-800/40 transition-all duration-300">
          
          <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
            Ready to Be Our Next Success Story?
          </h2>
          
          <p className="text-xl text-slate-300 leading-relaxed max-w-3xl mx-auto mb-10">
            Join our portfolio of successful clients who have transformed their businesses with <span className="font-semibold text-cyan-400">NOVO SOLS</span>. Let's discuss how we can help you achieve similar results and drive your digital transformation forward.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="group inline-flex items-center gap-3 px-10 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold rounded-2xl transition-all duration-300 hover:scale-105 text-lg shadow-lg shadow-cyan-500/25">
              <span>Start Your Project</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
            
            <button className="group inline-flex items-center gap-3 px-10 py-4 bg-slate-800/50 hover:bg-slate-700/50 text-cyan-400 font-bold rounded-2xl transition-all duration-300 hover:scale-105 text-lg border border-slate-600/50 hover:border-cyan-400/50">
              <span>Download Case Studies</span>
              <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
            </button>
          </div>
        </div>

        {/* Bottom Decorative Elements */}
        <div className="flex justify-center mt-16">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse delay-200"></div>
            <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse delay-400"></div>
          </div>
        </div>
      </section>
    </div>
  );
}