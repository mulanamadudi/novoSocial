"use client";
import { useState, useEffect } from "react";
import Link from "next/link";

interface Blog {
  _id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  thumbnail?: string;
  readTime: number;
  createdAt: string;
  author: {
    name: string;
  };
  category: {
    _id: string;
    name: string;
  };
}

interface Category {
  _id: string;
  name: string;
}

export default function BlogsPage() {
  const [blogs, setBlogs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("latest");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [page, setPage] = useState(1);

  const blogsPerPage = 10;

  // Fetch all categories
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_API_BASE}/categories`
        );
        const data = await res.json();
        setCategories(data);
      } catch (err) {
        console.error("Error fetching categories", err);
      }
    };
    fetchCategories();
  }, []);

  // Fetch filtered blogs
  const fetchBlogs = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.append("q", searchQuery);
      if (sortOption) params.append("sort", sortOption);
      if (selectedCategory) params.append("category", selectedCategory);

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_BASE}/blogs?${params.toString()}`
      );
      const data = await res.json();
      setBlogs(data);
      setPage(1); // Reset to first page on filter change
    } catch (err) {
      console.error("Error fetching blogs", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, [searchQuery, sortOption, selectedCategory]);

  const paginatedBlogs = blogs.slice(
    (page - 1) * blogsPerPage,
    page * blogsPerPage
  );

  const totalPages = Math.ceil(blogs.length / blogsPerPage);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <div className="relative z-10 container mx-auto px-6 py-20 max-w-7xl">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
            Tech Insights & Innovation
          </h1>
          <p className="text-xl text-slate-300 leading-relaxed max-w-3xl mx-auto">
            Navigate our blog wrapped with the latest technology knowledge,
            trends, innovations, and insights
          </p>
        </div>

        {/* Controls Section */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 mb-12">
          <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between">
            {/* Search Bar */}
            <div className="relative w-full md:w-1/3">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <svg
                  className="h-5 w-5 text-slate-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
              <input
                type="text"
                placeholder="Search by title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-slate-900/50 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-300"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-col md:flex-row gap-4">
              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 bg-slate-900/50 text-white border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-300"
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category._id} value={category._id}>
                    {category.name}
                  </option>
                ))}
              </select>

              {/* Sort Filter */}
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="px-4 py-3 bg-slate-900/50 text-white border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 transition-all duration-300"
              >
                <option value="latest">Latest First</option>
                <option value="oldest">Oldest First</option>
              </select>
            </div>
          </div>
        </div>

        {/* Blog Cards */}
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin"></div>
              <span className="text-slate-300 text-lg">
                Loading articles...
              </span>
            </div>
          </div>
        ) : paginatedBlogs.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg
                className="w-12 h-12 text-slate-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              No Articles Found
            </h3>
            <p className="text-slate-400">
              Try adjusting your search criteria or browse all categories.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {paginatedBlogs.map((blog, index) => (
              <article
                key={blog._id}
                className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl overflow-hidden hover:bg-slate-800/40 transition-all duration-300 group"
              >
                <div className="flex flex-col lg:flex-row">
                  {/* Left side - Date badge and thumbnail */}
                  <div className="lg:w-80 relative">
                    {/* Date Badge */}
                    <div className="absolute top-6 left-6 z-10">
                      <div className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg">
                        {formatDate(blog.createdAt)}
                      </div>
                    </div>

                    {/* Thumbnail */}
                    <div className="h-64 lg:h-full bg-gradient-to-br from-slate-700 to-slate-800 relative overflow-hidden">
                      {blog.thumbnail ? (
                        <img
                          src={blog.thumbnail}
                          alt={blog.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <svg
                            className="w-16 h-16 text-slate-500"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 011 .26l4 2.5a1 1 0 01.4.8V18a2 2 0 01-2 2z"
                            />
                          </svg>
                        </div>
                      )}

                      {/* Gradient overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
                    </div>
                  </div>

                  {/* Right side - Content */}
                  <div className="flex-1 p-8 lg:p-10">
                    <div className="space-y-4">
                      {/* Category */}
                      <div className="flex items-center space-x-4">
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                          {blog.category?.name ?? "Uncategorized"}
                        </span>
                        <span className="text-slate-400 text-sm">
                          by {blog.author.name}
                        </span>
                      </div>

                      {/* Title */}
                      <Link href={`/blogs/${blog.slug}`}>
                        <h2 className="text-2xl lg:text-3xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300 leading-tight cursor-pointer">
                          {blog.title}
                        </h2>
                      </Link>

                      {/* Excerpt */}
                      <p className="text-slate-300 text-lg leading-relaxed line-clamp-3">
                        {blog.excerpt}
                      </p>

                      {/* Footer */}
                      <div className="flex items-center justify-between pt-6 border-t border-slate-700/50">
                        <div className="flex items-center space-x-4 text-slate-400">
                          <div className="flex items-center space-x-2">
                            <svg
                              className="w-4 h-4"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                              />
                            </svg>
                            <span className="text-sm">
                              Reading Time: {blog.readTime} minutes
                            </span>
                          </div>
                        </div>

                        <Link href={`/blogs/${blog.slug}`}>
                          <button className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 hover:from-cyan-500/20 hover:to-blue-500/20 text-cyan-400 border border-cyan-500/20 hover:border-cyan-400/40 rounded-xl transition-all duration-300 group-hover:scale-105 cursor-pointer">
                            <span className="font-medium">Read More</span>
                            <svg
                              className="w-4 h-4"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M17 8l4 4m0 0l-4 4m4-4H3"
                              />
                            </svg>
                          </button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center space-x-2 pt-12">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:bg-slate-700/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>
            </button>

            {Array.from({ length: totalPages }, (_, i) => i + 1).map((num) => (
              <button
                key={num}
                className={`px-4 py-3 rounded-xl font-medium transition-all duration-300 ${
                  num === page
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25"
                    : "bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:bg-slate-700/50 hover:text-white"
                }`}
                onClick={() => setPage(num)}
              >
                {num}
              </button>
            ))}

            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:bg-slate-700/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// "use client";

// import { useEffect, useState } from "react";
// import BlogCard from "@/components/ui/BlogCard";
// import CategoryDropdown from "@/components/dropdown/CategoryDropdown";
// import SortDropdown from "@/components/dropdown/SortDropdown";

// interface Blog {
//   _id: string;
//   title: string;
//   excerpt: string;
//   content: string;
//   thumbnail?: string;
//   readTime: number;
//   createdAt: string;
//   slug: string;
//   author: {
//     name: string;
//   };
//   category: {
//     _id: string;
//     name: string;
//   };
// }

// interface Category {
//   _id: string;
//   name: string;
// }

// export default function BlogsPage() {
//   const [blogs, setBlogs] = useState<Blog[]>([]);
//   const [categories, setCategories] = useState<Category[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [searchQuery, setSearchQuery] = useState("");
//   const [sortOption, setSortOption] = useState("latest");
//   const [selectedCategory, setSelectedCategory] = useState("");
//   const [page, setPage] = useState(1);

//   const blogsPerPage = 10;

//   // Fetch all categories
//   useEffect(() => {
//     const fetchCategories = async () => {
//       try {
//         const res = await fetch(
//           `${process.env.NEXT_PUBLIC_API_BASE}/categories`
//         );
//         const data = await res.json();
//         setCategories(data);
//       } catch (err) {
//         console.error("Error fetching categories", err);
//       }
//     };
//     fetchCategories();
//   }, []);

//   // Fetch filtered blogs
//   const fetchBlogs = async () => {
//     setLoading(true);
//     try {
//       const params = new URLSearchParams();
//       if (searchQuery) params.append("q", searchQuery);
//       if (sortOption) params.append("sort", sortOption);
//       if (selectedCategory) params.append("category", selectedCategory);

//       const res = await fetch(
//         `${process.env.NEXT_PUBLIC_API_BASE}/blogs?${params.toString()}`
//       );
//       const data = await res.json();
//       setBlogs(data);
//       setPage(1); // Reset to first page on filter change
//     } catch (err) {
//       console.error("Error fetching blogs", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchBlogs();
//   }, [searchQuery, sortOption, selectedCategory]);

//   const paginatedBlogs = blogs.slice(
//     (page - 1) * blogsPerPage,
//     page * blogsPerPage
//   );

//   const totalPages = Math.ceil(blogs.length / blogsPerPage);

//   return (
//     <div className="max-w-6xl mx-auto px-4 py-10 space-y-6">
//       <h1 className="text-4xl font-bold text-white">Tech Blogs</h1>

//       {/* Controls */}
//       <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between">
//         <input
//           type="text"
//           placeholder="Search by title..."
//           value={searchQuery}
//           onChange={(e) => setSearchQuery(e.target.value)}
//           className="w-full md:w-1/3 px-4 py-2 rounded-md bg-slate-800 text-white placeholder-gray-400"
//         />
//         <div className="flex flex-col md:flex-row gap-4">
//           <CategoryDropdown
//             selected={selectedCategory}
//             onSelect={setSelectedCategory}
//           />
//           <SortDropdown selected={sortOption} onSelect={setSortOption} />
//         </div>
//       </div>

//       {/* Blog Cards */}
//       {loading ? (
//         <p className="text-white">Loading...</p>
//       ) : paginatedBlogs.length === 0 ? (
//         <p className="text-white">No blogs found.</p>
//       ) : (
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//           {paginatedBlogs.map((blog) => (
//             <BlogCard key={blog._id} blog={blog} />
//           ))}
//         </div>
//       )}

//       {/* Pagination */}
//       {totalPages > 1 && (
//         <div className="flex justify-center gap-4 pt-6">
//           {Array.from({ length: totalPages }, (_, i) => i + 1).map((num) => (
//             <button
//               key={num}
//               className={`px-4 py-2 rounded-md ${
//                 num === page
//                   ? "bg-blue-500 text-white"
//                   : "bg-gray-700 text-gray-300 hover:bg-gray-600"
//               }`}
//               onClick={() => setPage(num)}
//             >
//               {num}
//             </button>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }
