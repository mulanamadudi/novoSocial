"use client";

import { useState } from "react";

export default function ContactPage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    industry: "",
    services: "",
    timezone: "",
    notes: "",
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000));

      setSuccess(true);
      setForm({
        name: "",
        email: "",
        company: "",
        phone: "",
        industry: "",
        services: "",
        timezone: "",
        notes: "",
      });

      setTimeout(() => setSuccess(false), 5000);
    } catch (err) {
      console.error("Submission failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <div className="relative z-10 container mx-auto px-6 py-20 max-w-7xl">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left Column - Header & Info */}
          <div className="space-y-10">
            <div>
              <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
                Let's Build Something Amazing Together
              </h1>
              <p className="text-xl text-slate-300 leading-relaxed mb-8">
                Ready to transform your ideas into reality? Book up to{" "}
                <span className="text-cyan-400 font-semibold">$297</span> worth
                of expert consultation —{" "}
                <span className="text-cyan-400 font-semibold">
                  completely FREE
                </span>
                .
              </p>

              <div className="flex flex-wrap gap-6 mb-8">
                <div className="flex items-center space-x-3 text-slate-300">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse shadow-lg shadow-green-400/50"></div>
                  <span className="font-medium">No hidden fees</span>
                </div>
                <div className="flex items-center space-x-3 text-slate-300">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse shadow-lg shadow-green-400/50"></div>
                  <span className="font-medium">No obligation</span>
                </div>
                <div className="flex items-center space-x-3 text-slate-300">
                  <div className="w-3 h-3 bg-amber-400 rounded-full animate-pulse shadow-lg shadow-amber-400/50"></div>
                  <span className="font-medium">Limited slots</span>
                </div>
              </div>
            </div>

            {/* Contact Information Cards */}
            <div className="space-y-6">
              <div className="bg-slate-800/40 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:bg-slate-800/60 hover:border-cyan-500/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="w-14 h-14 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-all duration-300">
                    <svg
                      className="w-7 h-7 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-cyan-400 font-semibold mb-2 text-lg">
                      Our Office
                    </h3>
                    <p className="text-slate-300 leading-relaxed">
                      6B Meadow close, Westhead, Ormskirk, L40 6JS
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:bg-slate-800/60 hover:border-cyan-500/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="w-14 h-14 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-all duration-300">
                    <svg
                      className="w-7 h-7 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-cyan-400 font-semibold mb-2 text-lg">
                      Email Us
                    </h3>
                    <p className="text-slate-300">info@novosols.com</p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-6 hover:bg-slate-800/60 hover:border-cyan-500/30 transition-all duration-300 group">
                <div className="flex items-start space-x-4">
                  <div className="w-14 h-14 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-all duration-300">
                    <svg
                      className="w-7 h-7 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-cyan-400 font-semibold mb-2 text-lg">
                      WhatsApp Us
                    </h3>
                    <p className="text-slate-300">+44 (7349) 472-390</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Additional Info Section */}
            <div className="bg-slate-800/20 backdrop-blur-xl border border-slate-700/30 rounded-2xl p-6">
              <h3 className="text-white font-semibold mb-4 text-lg">
                Why Choose NovoSols?
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                  <span className="text-slate-300 text-sm">24/7 Support</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                  <span className="text-slate-300 text-sm">Expert Team</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                  <span className="text-slate-300 text-sm">Fast Delivery</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                  <span className="text-slate-300 text-sm">
                    Quality Assured
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Form */}
          <div className="relative">
            <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-8 space-y-6 shadow-2xl">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent mb-3">
                  Start Your Project
                </h2>
                <p className="text-slate-400 text-lg">
                  Fill out the form below and we'll get back to you within 24
                  hours
                </p>
              </div>

              {success && (
                <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 mb-6 animate-pulse">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shadow-lg shadow-green-500/50">
                      <svg
                        className="w-5 h-5 text-white"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                    <div>
                      <p className="text-green-400 font-semibold">Success!</p>
                      <p className="text-green-300 text-sm">
                        Message sent successfully! We'll be in touch soon.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 flex items-center space-x-1">
                      <span>Full Name</span>
                      <span className="text-red-400">*</span>
                    </label>
                    <input
                      name="name"
                      required
                      placeholder="John Doe"
                      value={form.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 flex items-center space-x-1">
                      <span>Email Address</span>
                      <span className="text-red-400">*</span>
                    </label>
                    <input
                      name="email"
                      type="email"
                      required
                      placeholder="john@company.com"
                      value={form.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300">
                      Company Name
                    </label>
                    <input
                      name="company"
                      placeholder="Your Company"
                      value={form.company}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300">
                      Phone Number
                    </label>
                    <input
                      name="phone"
                      placeholder="+1 (555) 123-4567"
                      value={form.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center space-x-1">
                    <span>Industry</span>
                    <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <select
                      name="industry"
                      required
                      onChange={handleChange}
                      value={form.industry}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300 appearance-none cursor-pointer"
                    >
                      <option value="" className="bg-slate-800 text-slate-400">
                        Select your industry
                      </option>
                      <option
                        value="Fintech"
                        className="bg-slate-800 text-white"
                      >
                        Fintech
                      </option>
                      <option
                        value="Healthcare"
                        className="bg-slate-800 text-white"
                      >
                        Healthcare
                      </option>
                      <option
                        value="E-commerce"
                        className="bg-slate-800 text-white"
                      >
                        E-commerce
                      </option>
                      <option value="IoT" className="bg-slate-800 text-white">
                        IoT
                      </option>
                      <option
                        value="Information Security"
                        className="bg-slate-800 text-white"
                      >
                        Information Security
                      </option>
                      <option
                        value="Mobile Development"
                        className="bg-slate-800 text-white"
                      >
                        Mobile Development
                      </option>
                      <option
                        value="Web Development"
                        className="bg-slate-800 text-white"
                      >
                        Web Development
                      </option>
                      <option
                        value="Data Analytics"
                        className="bg-slate-800 text-white"
                      >
                        Data Analytics
                      </option>
                      <option
                        value="Others"
                        className="bg-slate-800 text-white"
                      >
                        Others
                      </option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <svg
                        className="w-5 h-5 text-slate-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center space-x-1">
                    <span>Service Needed</span>
                    <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <select
                      name="services"
                      required
                      onChange={handleChange}
                      value={form.services}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300 appearance-none cursor-pointer"
                    >
                      <option value="" className="bg-slate-800 text-slate-400">
                        Select a service
                      </option>
                      <option
                        value="Fintech"
                        className="bg-slate-800 text-white"
                      >
                        Fintech Solutions
                      </option>
                      <option
                        value="Healthcare"
                        className="bg-slate-800 text-white"
                      >
                        Healthcare Technology
                      </option>
                      <option
                        value="E-commerce"
                        className="bg-slate-800 text-white"
                      >
                        E-commerce Development
                      </option>
                      <option value="IoT" className="bg-slate-800 text-white">
                        IoT Solutions
                      </option>
                      <option
                        value="Information Security"
                        className="bg-slate-800 text-white"
                      >
                        Information Security
                      </option>
                      <option
                        value="Mobile Development"
                        className="bg-slate-800 text-white"
                      >
                        Mobile App Development
                      </option>
                      <option
                        value="Web Development"
                        className="bg-slate-800 text-white"
                      >
                        Web Development
                      </option>
                      <option
                        value="Data Analytics"
                        className="bg-slate-800 text-white"
                      >
                        Data Analytics
                      </option>
                      <option
                        value="Others"
                        className="bg-slate-800 text-white"
                      >
                        Custom Solutions
                      </option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <svg
                        className="w-5 h-5 text-slate-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300 flex items-center space-x-1">
                    <span>Time Zone</span>
                    <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <select
                      name="timezone"
                      required
                      onChange={handleChange}
                      value={form.timezone}
                      className="w-full px-4 py-3 bg-slate-900/60 text-white border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300 appearance-none cursor-pointer"
                    >
                      <option value="" className="bg-slate-800 text-slate-400">
                        Select your timezone
                      </option>
                      <option value="EST" className="bg-slate-800 text-white">
                        EST (Eastern Standard Time)
                      </option>
                      <option value="CST" className="bg-slate-800 text-white">
                        CST (Central Standard Time)
                      </option>
                      <option value="PST" className="bg-slate-800 text-white">
                        PST (Pacific Standard Time)
                      </option>
                      <option value="GMT" className="bg-slate-800 text-white">
                        GMT (Greenwich Mean Time)
                      </option>
                      <option value="IST" className="bg-slate-800 text-white">
                        IST (India Standard Time)
                      </option>
                      <option value="JST" className="bg-slate-800 text-white">
                        JST (Japan Standard Time)
                      </option>
                      <option value="AEST" className="bg-slate-800 text-white">
                        AEST (Australian Eastern Standard Time)
                      </option>
                      <option value="Other" className="bg-slate-800 text-white">
                        Other
                      </option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                      <svg
                        className="w-5 h-5 text-slate-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-300">
                    Project Details
                  </label>
                  <textarea
                    name="notes"
                    rows={4}
                    value={form.notes}
                    onChange={handleChange}
                    placeholder="Tell us about your project requirements, timeline, budget, and any specific needs..."
                    className="w-full px-4 py-3 bg-slate-900/60 text-white placeholder-slate-400 border border-slate-600/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400/50 hover:border-slate-500/70 transition-all duration-300 resize-none"
                  />
                </div>

                <div className="bg-slate-900/40 border border-slate-700/50 rounded-xl p-4">
                  <p className="text-xs text-slate-400 leading-relaxed">
                    By submitting this form, you consent to receive marketing
                    communications from NovoSols. We respect your privacy and
                    you can unsubscribe at any time.{" "}
                    <span className="text-cyan-400 hover:text-cyan-300 cursor-pointer underline">
                      Privacy Policy
                    </span>
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full relative overflow-hidden px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold rounded-xl transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-70 disabled:hover:scale-100 shadow-lg hover:shadow-cyan-500/25 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="flex items-center justify-center space-x-3">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Sending Message...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center space-x-2">
                      <span>Send Message</span>
                      <svg
                        className="w-5 h-5 transition-transform group-hover:translate-x-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"
                        />
                      </svg>
                    </div>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


