"use client";

import { useState, useEffect } from 'react';
import { CheckCircle, Target, TrendingUp, Zap, ArrowRight, Sparkles } from 'lucide-react';

export default function AboutPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const expertiseItems = [
    { icon: Target, title: "Target Audience Engagement", desc: "Precision-targeted strategies that connect with your ideal customers" },
    { icon: TrendingUp, title: "Lead Conversion Optimization", desc: "Transform prospects into loyal customers with proven methodologies" },
    { icon: Zap, title: "Website Performance Enhancement", desc: "Boost your digital presence with cutting-edge optimization techniques" }
  ];

  return (
    <div className="pt-4 min-h-screen bg-slate-900 relative overflow-hidden">
      {/* Animated Background - Matching Blog Page */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(34, 211, 238, 0.15) 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
      ></div>

      <div className="relative z-10 container mx-auto px-6 py-20 max-w-7xl">
        {/* Header Section - Matching Blog Page Style */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-full px-4 py-2 mb-8">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 text-sm font-medium">About Our Company</span>
          </div>
          
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent leading-tight">
            About NOVO SOLS
          </h1>
          
          <div className="max-w-4xl mx-auto space-y-6 text-lg leading-relaxed">
            <p className="text-slate-300 hover:text-white transition-colors duration-300">
              At <span className="font-semibold text-cyan-400">NOVO SOLS</span>, we turn bold ideas into impactful digital solutions. We specialize in enabling startups, SMEs, and scaling enterprises to accelerate growth through tailored IT services and digital transformation strategies.
            </p>
            <p className="text-slate-300 hover:text-white transition-colors duration-300">
              Whether it's custom software development, automation, or cloud integration, we focus on practical innovation that delivers measurable business outcomes. Our client-centric approach ensures that every solution is aligned with your unique goals—helping you operate smarter, scale faster, and stay ahead in a rapidly changing digital world.
            </p>
            <p className="text-xl font-semibold text-cyan-400">
              NOVO SOLS is your strategic partner for growth, agility, and long-term technology success.
            </p>
          </div>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300 group hover:scale-105">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">Mission</h2>
            </div>
            <p className="text-slate-300 text-lg leading-relaxed group-hover:text-white transition-colors duration-300">
              Empowering businesses to thrive through purposeful innovation, advanced technology, and exceptional service that transforms challenges into opportunities.
            </p>
          </div>
          
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 hover:bg-slate-800/40 transition-all duration-300 group hover:scale-105">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">Vision</h2>
            </div>
            <p className="text-slate-300 text-lg leading-relaxed group-hover:text-white transition-colors duration-300">
              To be the global partner of choice for driving digital transformation and sustainable business growth across industries worldwide.
            </p>
          </div>
        </div>

        {/* Our Expertise Section */}
        <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-12">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Our Expertise
            </h2>
            <p className="text-xl text-slate-300 leading-relaxed max-w-4xl mx-auto">
              At <span className="font-semibold text-cyan-400">NOVO SOLS</span>, we drive your business forward with data-driven marketing strategies. With over a decade of expertise, our team ensures practical and significant results. We offer tailored marketing services to meet your customized business needs and accelerate growth.
            </p>
          </div>

          {/* Expertise Grid */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {expertiseItems.map((item, index) => (
              <div key={index} className="bg-slate-800/50 border border-slate-700/50 rounded-2xl p-6 hover:bg-slate-800/70 transition-all duration-300 group hover:scale-105">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-400 to-cyan-400 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-cyan-400 transition-colors duration-300">
                  {item.title}
                </h3>
                <p className="text-slate-300 group-hover:text-white transition-colors duration-300">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <div className="text-center">
            <button className="group inline-flex items-center gap-3 px-10 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold rounded-2xl transition-all duration-300 hover:scale-105 text-lg shadow-lg shadow-cyan-500/25">
              <span>Get Started Today</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 text-center hover:bg-slate-800/40 transition-all duration-300 group">
            <div className="text-4xl font-bold text-cyan-400 mb-2 group-hover:scale-110 transition-transform duration-300">10+</div>
            <div className="text-slate-300 font-medium">Years Experience</div>
          </div>
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 text-center hover:bg-slate-800/40 transition-all duration-300 group">
            <div className="text-4xl font-bold text-blue-400 mb-2 group-hover:scale-110 transition-transform duration-300">500+</div>
            <div className="text-slate-300 font-medium">Projects Completed</div>
          </div>
          <div className="bg-slate-800/30 backdrop-blur-xl border border-slate-700/50 rounded-2xl p-8 text-center hover:bg-slate-800/40 transition-all duration-300 group">
            <div className="text-4xl font-bold text-green-400 mb-2 group-hover:scale-110 transition-transform duration-300">98%</div>
            <div className="text-slate-300 font-medium">Client Satisfaction</div>
          </div>
        </div>

        {/* Bottom Decorative Elements */}
        <div className="flex justify-center mt-16">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse delay-200"></div>
            <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse delay-400"></div>
          </div>
        </div>
      </div>
    </div>
  );
}