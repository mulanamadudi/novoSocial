// app/layout.tsx

import "./globals.css";
import { Inter } from "next/font/google";
import ClientLayoutWrapper from "@/app/LayoutWithConditionalHeaderFooter";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Novo Sols",
  description: "Modern Tech Startup Website",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body
        className={`${inter.className} bg-gradient-to-br from-blue-900 via-slate-900 to-blue-900 text-white`}
      >
        <ClientLayoutWrapper>{children}</ClientLayoutWrapper>
      </body>
    </html>
  );
}