"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";

import Sidebar from "@/components/layout/Sidebar";

// Dynamically import dashboard components
const DefaultDashboard = dynamic(() => import("./components/DefaultDashboard"));
const CreateAdmin = dynamic(() => import("./components/CreateAdmin"));
const ListAdmins = dynamic(() => import("./components/ListAdmins"));
const CreateBlog = dynamic(() => import("./components/CreateBlog"));
const CreateCategory = dynamic(() => import("./components/CreateCategory"));
const ListBlogs = dynamic(() => import("./components/ListBlogs"));
const ContactForms = dynamic(() => import("./components/ContactForms"));
const NewsletterSubscribers = dynamic(
  () => import("./components/NewsletterSubscribers")
);

export default function AdminDashboardPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);
  const [admin, setAdmin] = useState<null | {
    name: string;
    email: string;
    isSuperAdmin: boolean;
  }>(null);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const res = await axios.get(
          `${process.env.NEXT_PUBLIC_API_BASE}/auth/me`,
          {
            withCredentials: true,
          }
        );

        if (res.data?.loggedIn && res.data.admin) {
          setAdmin(res.data.admin); // contains name, email, isSuperAdmin
        } else {
          router.push("/admin");
        }
      } catch (err) {
        console.error("Auth check failed:", err);
        router.push("/admin");
      } finally {
        setLoading(false);
      }
    };

    checkLoginStatus();
  }, [router]);

  const renderComponent = () => {
    switch (activeTab) {
      case "create-admin":
        return <CreateAdmin />;
      case "list-admins":
        return <ListAdmins />;
      case "create-blog":
        return <CreateBlog />;
      case "create-category":
        return <CreateCategory />;
      case "list-blogs":
        return <ListBlogs />;
      case "contact-forms":
        return <ContactForms />;
      case "newsletter":
        return <NewsletterSubscribers />;
      default:
        return <DefaultDashboard />;
    }
  };

  if (loading) {
    return <div className="text-white p-10">Checking admin status...</div>;
  }

  if (!admin) return null; // block UI if no admin

  return (
    <div className="flex min-h-screen">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isSuperAdmin={admin.isSuperAdmin}
      />
      <main className="flex-1 p-6 bg-[#0f172a]">{renderComponent()}</main>
    </div>
  );
}
