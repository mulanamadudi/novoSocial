"use client";

import { useEffect, useState } from "react";
import axios from "axios";

interface Subscriber {
  _id: string;
  email: string;
  isVerified: boolean;
  createdAt: string;
}

export default function NewsletterSubscribers() {
  const [verified, setVerified] = useState<Subscriber[]>([]);
  const [unverified, setUnverified] = useState<Subscriber[]>([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    const fetchSubscribers = async () => {
      try {
        const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/newsletter/status`, {
          withCredentials: true,
        });
        setVerified(res.data.verified || []);
        setUnverified(res.data.unverified || []);
      } catch (err) {
        console.error("Error fetching newsletter subscribers", err);
      }
    };

    fetchSubscribers();
  }, []);

  const getFilteredSubscribers = () => {
    if (filter === "verified") return verified;
    if (filter === "unverified") return unverified;
    return [...verified, ...unverified];
  };

  const downloadCSV = () => {
    const rows = [["Email", "Status", "Subscribed At"]];

    getFilteredSubscribers().forEach((sub) => {
      rows.push([
        sub.email,
        sub.isVerified ? "Verified" : "Unverified",
        new Date(sub.createdAt).toLocaleString(),
      ]);
    });

    const csvContent = rows.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "newsletter_subscribers.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="text-white">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-3">
        <h1 className="text-2xl font-bold">Newsletter Subscribers</h1>

        <div className="flex gap-3 items-center">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          >
            <option value="all">All</option>
            <option value="verified">Verified</option>
            <option value="unverified">Unverified</option>
          </select>

          <button
            onClick={downloadCSV}
            className="px-4 py-2 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition"
          >
            Download CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full border border-white/20 rounded-md bg-white/5">
          <thead>
            <tr className="bg-white/10 text-left">
              <th className="p-3 border-b border-white/20">Email</th>
              <th className="p-3 border-b border-white/20">Status</th>
              <th className="p-3 border-b border-white/20">Subscribed At</th>
            </tr>
          </thead>
          <tbody>
            {getFilteredSubscribers().map((sub) => (
              <tr key={sub._id} className="hover:bg-white/10 transition">
                <td className="p-3">{sub.email}</td>
                <td className="p-3">
                  {sub.isVerified ? (
                    <span className="text-green-400 font-semibold">Verified</span>
                  ) : (
                    <span className="text-yellow-400 font-semibold">Unverified</span>
                  )}
                </td>
                <td className="p-3">{new Date(sub.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
