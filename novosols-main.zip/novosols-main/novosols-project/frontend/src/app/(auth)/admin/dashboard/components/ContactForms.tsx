"use client";

import { useEffect, useState } from "react";
import axios from "axios";

interface Contact {
  _id: string;
  name: string;
  email: string;
  company: string;
  phone: string;
  industry: string;
  services: string;
  timezone: string;
  notes: string;
  createdAt: string;
}

export default function ContactForms() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [filteredContacts, setFilteredContacts] = useState<Contact[]>([]);
  const [industryFilter, setIndustryFilter] = useState("all");
  const [servicesFilter, setServicesFilter] = useState("all");
  const [timezoneFilter, setTimezoneFilter] = useState("all");

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/contact`, {
          withCredentials: true,
        });
        const sorted = res.data.sort(
          (a: Contact, b: Contact) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setContacts(sorted);
        setFilteredContacts(sorted);
      } catch (err) {
        console.error("Error fetching contact forms", err);
      }
    };

    fetchContacts();
  }, []);

  useEffect(() => {
    const filtered = contacts.filter((contact) => {
      const matchesIndustry = industryFilter === "all" || contact.industry === industryFilter;
      const matchesServices = servicesFilter === "all" || contact.services === servicesFilter;
      const matchesTimezone = timezoneFilter === "all" || contact.timezone === timezoneFilter;
      return matchesIndustry && matchesServices && matchesTimezone;
    });

    setFilteredContacts(filtered);
  }, [industryFilter, servicesFilter, timezoneFilter, contacts]);

  const uniqueIndustries = Array.from(new Set(contacts.map((c) => c.industry)));
  const uniqueServices = Array.from(new Set(contacts.map((c) => c.services)));
  const uniqueTimezones = Array.from(new Set(contacts.map((c) => c.timezone)));

  const downloadCSV = () => {
    const rows = [["Name", "Email", "Company", "Phone", "Industry", "Services", "Timezone", "Notes", "Created At"]];
    filteredContacts.forEach((c) => {
      rows.push([
        c.name,
        c.email,
        c.company,
        c.phone,
        c.industry,
        c.services,
        c.timezone,
        c.notes || "-",
        new Date(c.createdAt).toLocaleString(),
      ]);
    });

    const csvContent = rows.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "contact_forms.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="text-white">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4 gap-3">
        <h1 className="text-2xl font-bold">
          Contact Forms <span className="text-sm font-normal">({filteredContacts.length} entries)</span>
        </h1>

        <div className="flex flex-wrap gap-3">
          <select
            value={industryFilter}
            onChange={(e) => setIndustryFilter(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          >
            <option value="all">All Industries</option>
            {uniqueIndustries.map((ind) => (
              <option key={ind} value={ind}>
                {ind}
              </option>
            ))}
          </select>

          <select
            value={servicesFilter}
            onChange={(e) => setServicesFilter(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          >
            <option value="all">All Services</option>
            {uniqueServices.map((srv) => (
              <option key={srv} value={srv}>
                {srv}
              </option>
            ))}
          </select>

          <select
            value={timezoneFilter}
            onChange={(e) => setTimezoneFilter(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          >
            <option value="all">All Timezones</option>
            {uniqueTimezones.map((tz) => (
              <option key={tz} value={tz}>
                {tz}
              </option>
            ))}
          </select>

          <button
            onClick={downloadCSV}
            className="px-4 py-2 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition"
          >
            Download CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full border border-white/20 rounded-md bg-white/5">
          <thead>
            <tr className="bg-white/10 text-left">
              <th className="p-3 border-b border-white/20">Name</th>
              <th className="p-3 border-b border-white/20">Email</th>
              <th className="p-3 border-b border-white/20">Company</th>
              <th className="p-3 border-b border-white/20">Phone</th>
              <th className="p-3 border-b border-white/20">Industry</th>
              <th className="p-3 border-b border-white/20">Services</th>
              <th className="p-3 border-b border-white/20">Timezone</th>
              <th className="p-3 border-b border-white/20">Notes</th>
              <th className="p-3 border-b border-white/20">Submitted At</th>
            </tr>
          </thead>
          <tbody>
            {filteredContacts.map((c) => (
              <tr key={c._id} className="hover:bg-white/10 transition">
                <td className="p-3">{c.name}</td>
                <td className="p-3">{c.email}</td>
                <td className="p-3">{c.company}</td>
                <td className="p-3">{c.phone}</td>
                <td className="p-3">{c.industry}</td>
                <td className="p-3">{c.services}</td>
                <td className="p-3">{c.timezone}</td>
                <td className="p-3">{c.notes || "-"}</td>
                <td className="p-3">{new Date(c.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
