export default function DefaultDashboard() {
  return (
    <div className="text-white text-xl font-bold">
      Welcome to the Admin Dashboard!
    </div>
  );
}
