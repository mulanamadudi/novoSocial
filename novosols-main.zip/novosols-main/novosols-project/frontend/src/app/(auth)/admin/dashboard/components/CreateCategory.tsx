"use client";

import { useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import ReadOnlyCategoryList from "@/components/dropdown/ReadOnlyCategoryList";

export default function CreateCategory() {
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0); // for triggering refresh

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error("Category name cannot be empty");
      return;
    }

    try {
      setLoading(true);
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_API_BASE}/categories/create`,
        { name },
        { withCredentials: true }
      );

      toast.success("Category created successfully!");
      setName("");
      setRefreshTrigger((prev) => prev + 1); // trigger refresh
    } catch (err: any) {
      const msg =
        err?.response?.data?.message || "Failed to create category";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="text-white max-w-md">
      <h2 className="text-2xl font-bold mb-4">Create a New Category</h2>

      <div className="flex flex-col gap-3">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter category name"
          className="px-4 py-2 rounded-md bg-white/10 text-white border border-white/20"
        />

        <button
          onClick={handleCreate}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md disabled:opacity-50"
        >
          {loading ? "Creating..." : "Create Category"}
        </button>
      </div>

      <ReadOnlyCategoryList refreshTrigger={refreshTrigger} />
    </div>
  );
}
