"use client";

import { useEffect, useState } from "react";
import axios from "axios";

interface Admin {
  _id: string;
  name: string;
  email: string;
  isSuperAdmin: boolean;
}

export default function ListAdmins() {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [currentAdminId, setCurrentAdminId] = useState("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      // Get current admin first
      const resMe = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/auth/me`, {
        withCredentials: true,
      });

      setCurrentAdminId(resMe.data.admin._id);
      setIsSuperAdmin(resMe.data.admin.isSuperAdmin);

      // Now get list of all admins
      const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/auth/admins`, {
        withCredentials: true,
      });
      setAdmins(res.data);
    } catch (err: any) {
      console.error(err);
      setError(err?.response?.data?.message || "Failed to load admins.");
    }
  };

  const handleDelete = async (id: string) => {
    const confirmDelete = confirm("Are you sure you want to delete this admin?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`${process.env.NEXT_PUBLIC_API_BASE}/auth/admins/${id}`, {
        withCredentials: true,
      });
      setAdmins(admins.filter((admin) => admin._id !== id));
    } catch (err: any) {
      alert(err?.response?.data?.message || "Delete failed.");
    }
  };

  return (
    <div className="bg-[#1e293b] p-6 rounded-lg text-white">
      <h2 className="text-2xl font-bold mb-4">All Admins</h2>

      {error && <p className="text-red-400 mb-4">{error}</p>}

      <div className="overflow-x-auto">
        <table className="w-full table-auto border border-white/20">
          <thead>
            <tr className="bg-[#334155]">
              <th className="p-3 text-left">Name</th>
              <th className="p-3 text-left">Email</th>
              <th className="p-3 text-left">Role</th>
              {isSuperAdmin && <th className="p-3 text-left">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {admins.map((admin) => (
              <tr key={admin._id} className="border-t border-white/10">
                <td className="p-3">{admin.name}</td>
                <td className="p-3">{admin.email}</td>
                <td className="p-3">{admin.isSuperAdmin ? "Super Admin" : "Sub Admin"}</td>
                {isSuperAdmin && (
                  <td className="p-3">
                    {admin._id !== currentAdminId && (
                      <button
                        onClick={() => handleDelete(admin._id)}
                        className="px-3 py-1 rounded bg-red-500 hover:bg-red-600 text-sm"
                      >
                        Delete
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
