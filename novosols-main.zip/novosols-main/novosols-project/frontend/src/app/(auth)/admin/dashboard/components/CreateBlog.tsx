"use client";

import { useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import CategoryDropdown from "@/components/dropdown/CategoryDropdown";
import RichTextEditor from "@/components/forms/RichTextEditor";

export default function CreateBlog() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("");
  const [tags, setTags] = useState("");
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!title || !content || !category) {
      toast.error("Please fill all required fields.");
      return;
    }

    try {
      setLoading(true);

      let thumbnailUrl = "";

      // 1. Upload image if file selected
      if (thumbnailFile) {
        const formData = new FormData();
        formData.append("image", thumbnailFile);

        const uploadRes = await axios.post(
          `${process.env.NEXT_PUBLIC_API_BASE}/upload`,
          formData,
          {
            headers: { "Content-Type": "multipart/form-data" },
            withCredentials: true,
          }
        );

        thumbnailUrl = uploadRes.data.url;
      }

      // 2. Send blog creation request
      const blogPayload = {
        title,
        content,
        category,
        tags: tags.split(",").map((tag) => tag.trim()),
        thumbnail: thumbnailUrl,
      };

      await axios.post(
        `${process.env.NEXT_PUBLIC_API_BASE}/blogs/create`,
        blogPayload,
        { withCredentials: true }
      );

      toast.success("Blog created successfully!");
      setTitle("");
      setContent("");
      setCategory("");
      setTags("");
      setThumbnailFile(null);
    } catch (err: any) {
      console.error(err);
      const msg =
        err?.response?.data?.message || "Failed to create blog post";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-white">
      <h2 className="text-2xl font-bold mb-4">Create New Blog</h2>

      <div className="flex flex-col gap-4">
        <input
          type="text"
          placeholder="Blog Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="px-4 py-2 rounded-md bg-white/10 border border-white/20"
        />

        {/* <textarea
          placeholder="Write your content..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="px-4 py-2 rounded-md bg-white/10 border border-white/20 min-h-[120px]"
        /> */}
        <RichTextEditor value={content} onChange={setContent} />


        <CategoryDropdown selected={category} onSelect={setCategory} />

        <input
          type="text"
          placeholder="Comma-separated tags (e.g., tech,ai)"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          className="px-4 py-2 rounded-md bg-white/10 border border-white/20"
        />

        <input
          type="file"
          accept="image/*"
          onChange={(e) => setThumbnailFile(e.target.files?.[0] || null)}
          className="text-white"
        />

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md disabled:opacity-50"
        >
          {loading ? "Submitting..." : "Create Blog"}
        </button>
      </div>
    </div>
  );
}
