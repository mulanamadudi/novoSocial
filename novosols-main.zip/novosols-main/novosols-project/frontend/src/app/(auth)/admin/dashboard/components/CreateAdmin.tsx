"use client";

import { useState } from "react";
import axios from "axios";

export default function CreateAdmin() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    isSuperAdmin: false,
  });

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_API_BASE}/auth/admins/create`,
        formData,
        { withCredentials: true }
      );
      setMessage(res.data.message);
      setFormData({
        name: "",
        email: "",
        password: "",
        isSuperAdmin: false,
      });
    } catch (err: any) {
      setError(err?.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="bg-[#1e293b] p-6 rounded-lg max-w-xl text-white">
      <h2 className="text-2xl font-bold mb-4">Create New Admin</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 rounded bg-white/10 border border-white/20 text-white"
            required
          />
        </div>

        <div>
          <label className="block mb-1">Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-4 py-2 rounded bg-white/10 border border-white/20 text-white"
            required
          />
        </div>

        <div>
          <label className="block mb-1">Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="w-full px-4 py-2 rounded bg-white/10 border border-white/20 text-white"
            required
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            name="isSuperAdmin"
            checked={formData.isSuperAdmin}
            onChange={handleChange}
            className="accent-cyan-400"
          />
          <label>Super Admin</label>
        </div>

        <button
          type="submit"
          className="px-6 py-2 rounded bg-cyan-500 hover:bg-cyan-600 font-semibold"
        >
          Create Admin
        </button>
      </form>

      {message && <p className="text-green-400 mt-4">{message}</p>}
      {error && <p className="text-red-400 mt-4">{error}</p>}
    </div>
  );
}
