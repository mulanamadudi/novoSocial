"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import CategoryDropdown from "@/components/dropdown/CategoryDropdown";

interface Blog {
  _id: string;
  title: string;
  slug: string;
  author: { name: string };
  category: { name: string };
  createdAt: string;
  readTime: number;
}

export default function ListBlogs() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [search, setSearch] = useState("");
  const [authors, setAuthors] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedAuthor, setSelectedAuthor] = useState("");

  useEffect(() => {
    fetchBlogs();
  }, [search, selectedCategory, selectedAuthor]);

  const fetchBlogs = async () => {
    try {
      const params: any = {};
      if (search) params.q = search;
      if (selectedCategory) params.category = selectedCategory;

      const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE}/blogs`, {
        params,
        withCredentials: true,
      });

      const allBlogs: Blog[] = res.data;

      const uniqueAuthors = [...new Set(allBlogs.map((b) => b.author?.name))];
      setAuthors(uniqueAuthors);

      const filtered = selectedAuthor
        ? allBlogs.filter((b) => b.author?.name === selectedAuthor)
        : allBlogs;

      setBlogs(filtered);
    } catch (err) {
      console.error("Failed to fetch blogs", err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this blog?")) return;
    try {
      await axios.delete(`${process.env.NEXT_PUBLIC_API_BASE}/blogs/${id}`, {
        withCredentials: true,
      });
      fetchBlogs();
    } catch (err) {
      console.error("Failed to delete blog", err);
    }
  };

  const downloadCSV = () => {
    const rows = [["Title", "Author", "Category", "Published At", "Read Time"]];
    blogs.forEach((b) => {
      rows.push([
        b.title,
        b.author?.name,
        b.category?.name,
        new Date(b.createdAt).toLocaleString(),
        `${b.readTime} min`,
      ]);
    });

    const csvContent = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "blogs_list.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="text-white">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
        <h1 className="text-2xl font-bold">All Blogs</h1>
        <div className="flex gap-2 flex-wrap">
          <input
            type="text"
            placeholder="Search by title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          />

          <CategoryDropdown
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />

          <select
            value={selectedAuthor}
            onChange={(e) => setSelectedAuthor(e.target.value)}
            className="px-3 py-2 rounded-md text-black"
          >
            <option value="">All Authors</option>
            {authors.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>

          <button
            onClick={downloadCSV}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            Download CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <p className="text-sm text-white mb-2">
          ({blogs.length} {blogs.length === 1 ? "entry" : "entries"})
        </p>
        <table className="min-w-full border border-white/20 rounded-md bg-white/5">
          <thead>
            <tr className="bg-white/10 text-left">
              <th className="p-3 border-b border-white/20">Title</th>
              <th className="p-3 border-b border-white/20">Author</th>
              <th className="p-3 border-b border-white/20">Category</th>
              <th className="p-3 border-b border-white/20">Read Time</th>
              <th className="p-3 border-b border-white/20">Created At</th>
              <th className="p-3 border-b border-white/20">Actions</th>
            </tr>
          </thead>
          <tbody>
            {blogs.map((blog) => (
              <tr key={blog._id} className="hover:bg-white/10">
                {/* <td className="p-3">{blog.title}</td> */}
                <td className="p-3">
                  <a
                    href={`/blogs/${blog.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 underline hover:text-blue-300"
                  >
                    {blog.title}
                  </a>
                </td>

                <td className="p-3">{blog.author?.name}</td>
                <td className="p-3">{blog.category?.name}</td>
                <td className="p-3">{blog.readTime} min</td>
                <td className="p-3">
                  {new Date(blog.createdAt).toLocaleString()}
                </td>
                <td className="p-3">
                  <button
                    onClick={() => handleDelete(blog._id)}
                    className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}

            {blogs.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center p-6 text-white/60">
                  No blogs found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
