"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function ConfirmSubscriptionPage() {
  const searchParams = useSearchParams();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");

  useEffect(() => {
    const token = searchParams.get("token");

    if (!token) {
      setStatus("error");
      return;
    }

    fetch(`${process.env.NEXT_PUBLIC_API_BASE}/newsletter/confirm?token=${token}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed");
        return res.json();
      })
      .then(() => setStatus("success"))
      .catch(() => setStatus("error"));
  }, [searchParams]);

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <div className="max-w-xl w-full text-center bg-white/5 border border-white/10 rounded-xl px-8 py-14 backdrop-blur">
        {status === "loading" && (
          <p className="text-white text-xl font-medium">⏳ Verifying your subscription...</p>
        )}

        {status === "success" && (
          <>
            <h1 className="text-3xl font-bold text-cyan-400 mb-4">✅ Thank You!</h1>
            <p className="text-gray-300">
              Your newsletter subscription has been confirmed successfully.
            </p>
          </>
        )}

        {status === "error" && (
          <>
            <h1 className="text-3xl font-bold text-red-500 mb-4">❌ Invalid or Expired Link</h1>
            <p className="text-gray-300">
              We couldn't verify your subscription. Please try subscribing again.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
import { Suspense } from "react";