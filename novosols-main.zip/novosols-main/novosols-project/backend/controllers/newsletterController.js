const crypto = require("crypto");
const Newsletter = require("../models/Newsletter");
const { sendNewsletterConfirmation } = require("../utils/mailer");

const subscribeNewsletter = async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: "Email is required" });

  try {
    let existing = await Newsletter.findOne({ email });

    if (existing && existing.isVerified) {
      return res.status(400).json({ message: "Already subscribed" });
    }

    const token = crypto.randomBytes(32).toString("hex");

    if (existing) {
      existing.token = token;
      await existing.save();
    } else {
      await Newsletter.create({
        email,
        token,
        isVerified: false,
      });
    }

    await sendNewsletterConfirmation(email, token);
    res.status(200).json({ message: "Confirmation email sent" });
  } catch (err) {
    console.error("Error in subscribeNewsletter:", err);
    res.status(500).json({ message: "Server error" });
  }
};

const confirmSubscription = async (req, res) => {
  const { token } = req.query;

  if (!token) return res.status(400).json({ message: "Invalid token" });

  try {
    const subscriber = await Newsletter.findOne({ token });
    if (!subscriber) return res.status(400).json({ message: "Token not found" });

    subscriber.isVerified = true;
    subscriber.token = null;
    await subscriber.save();

    res.status(200).json({ message: "Smeubscription confird" });
  } catch (err) {
    console.error("Error in confirmSubscription:", err);
    res.status(500).json({ message: "Server error" });
  }
};

const unsubscribeNewsletter = async (req, res) => {
  const { email } = req.query;

  if (!email) {
    return res.status(400).json({ message: "Email is required" });
  }

  try {
    const subscriber = await Newsletter.findOneAndUpdate(
      { email },
      { isVerified: false },
      { new: true }
    );

    if (!subscriber) {
      return res.status(404).json({ message: "Subscriber not found" });
    }

    res.status(200).json({ message: "Unsubscribed successfully" });
  } catch (err) {
    console.error("Error in unsubscribeNewsletter:", err);
    res.status(500).json({ message: "Server error" });
  }
};

const getNewsletterStatus = async (req, res) => {
  try {
    const verified = await Newsletter.find({ isVerified: true });
    const unverified = await Newsletter.find({ isVerified: false });

    res.status(200).json({
      verified,
      unverified,
    });
  } catch (err) {
    console.error("Error in getNewsletterStatus:", err);
    res.status(500).json({ message: "Server error" });
  }
};


module.exports = {
  subscribeNewsletter,
  confirmSubscription,
  unsubscribeNewsletter,
  getNewsletterStatus,
};
