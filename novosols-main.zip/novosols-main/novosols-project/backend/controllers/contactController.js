const Contact = require("../models/Contact");
const { sendConfirmationEmail } = require("../utils/mailer");

const handleContactForm = async (req, res) => {
  try {
    const { name, email, company, phone, industry, services, timezone, notes } =
      req.body;

    // Save to MongoDB
    const newContact = new Contact({
      name,
      email,
      company,
      phone,
      industry,
      services,
      timezone,
      notes,
    });

    await newContact.save();

    // Send confirmation email
    await sendConfirmationEmail(email, name);

    return res.status(200).json({ message: "Form submitted successfully." });
  } catch (err) {
    console.error("Error in contactController:", err);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const getAllContacts = async (req, res) => {
  try {
    // const contacts = await Contact.find({}, { __v: 0 });
    const contacts = await Contact.find({}, { __v: 0 }).sort({ createdAt: -1 });
    res.status(200).json(contacts);
  } catch (err) {
    console.error("Error fetching contact forms:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

module.exports = {
  handleContactForm,
  getAllContacts,
};
