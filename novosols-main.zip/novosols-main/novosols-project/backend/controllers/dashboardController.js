const Admin = require("../models/Admin");
const Blog = require("../models/Blog");
const Contact = require("../models/Contact");
const Newsletter = require("../models/Newsletter");

const getDashboardStats = async (req, res) => {
  try {
    const [admins, blogs, contacts, newsletters] = await Promise.all([
      Admin.countDocuments(),
      Blog.countDocuments(),
      Contact.countDocuments(),
      Newsletter.countDocuments({ isVerified: true }),
    ]);

    res.status(200).json({
      totalAdmins: admins,
      totalBlogs: blogs,
      totalContacts: contacts,
      totalNewsletters: newsletters,
    });
  } catch (err) {
    console.error("Error fetching dashboard stats:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

module.exports = { getDashboardStats };