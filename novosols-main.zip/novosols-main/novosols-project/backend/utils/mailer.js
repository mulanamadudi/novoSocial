const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// const transporter = nodemailer.createTransport({
//   host: "smtp.hostinger.com",   // Outgoing SMTP server
//   port: 465,                    // SSL port (secure)
//   secure: true,                 // Use SSL (true for port 465)
//   auth: {
//     user: process.env.EMAIL_USER, // e.g. info@novosols.com
//     pass: process.env.EMAIL_PASS, // Your mailbox password
//   },
// });

// Send test email
transporter.sendMail(
  {
    from: '"Novo Sols" <info@novosols.com>',
    to: "saqibalijavaid2@gmail.com", // Change to your real email to receive the test
    subject: "Test Email from NovoSols",
    text: "✅ Success! This is a test email from your new domain setup.",
  },
  (error, info) => {
    if (error) {
      return console.log("❌ Error:", error);
    }
    console.log("✅ Email sent:", info.response);
  }
);

const sendConfirmationEmail = async (toEmail, userName) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: toEmail,
    subject: "Thanks for Contacting Novosols!",
    text: `Hi ${userName},\n\nThank you for reaching out. Our team will contact you shortly.\n\n— Novosols Team`,
  };

  return transporter.sendMail(mailOptions);
};

const sendNewsletterConfirmation = async (toEmail, token) => {
  // const confirmUrl = `http://localhost:3000/newsletter/confirm?token=${token}`; // or your real frontend URL
  const confirmUrl = `${process.env.FRONTEND_API}/newsletter/confirm?token=${token}`; // or your real frontend URL
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: toEmail,
    subject: "Confirm your subscription to Novosols",
    html: `
      <p>Thanks for subscribing!</p>
      <p>Click below to confirm your subscription:</p>
      <a href="${confirmUrl}" target="_blank">Confirm Subscription</a>
    `,
  };

  return transporter.sendMail(mailOptions);
};

module.exports = {
  sendConfirmationEmail,
  sendNewsletterConfirmation,
};
