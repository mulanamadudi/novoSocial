const mongoose = require("mongoose");

const contactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  company: { type: String, required: true },
  phone: { type: String, required: true },
  industry: { type: String, required: true },
  services: { type: String, required: true },
  timezone: { type: String, required: true },
  notes: { type: String },
  createdAt: { type: Date, default: Date.now },
});

// module.exports = mongoose.model("Contact", contactSchema);
// 🛡️ Prevent OverwriteModelError
module.exports = mongoose.models.Contact || mongoose.model("Contact", contactSchema);
