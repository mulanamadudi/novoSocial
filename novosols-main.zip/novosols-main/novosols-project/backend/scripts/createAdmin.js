// node scripts/createAdmin.js
// Use this script to create an initial admin user in the database.
// This script connects to MongoDB, creates an admin user with the credentials from the .env file,

// Wrong => C:\Users\saqibalijavaid\Desktop\PROJECTS\novosols\backend\scripts>node createAdmin.js
// Correct => C:\Users\saqibalijavaid\Desktop\PROJECTS\novosols\backend>node scripts/createAdmin.js


const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Admin = require('../models/Admin');

// Load env variables
dotenv.config();

const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;

async function createAdmin() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ MongoDB connected');

    const existingAdmin = await Admin.findOne({ email: ADMIN_EMAIL });

    if (existingAdmin) {
      console.log('⚠️ Admin with this email already exists:', ADMIN_EMAIL);
    } else {
      const admin = new Admin({
        name: ADMIN_NAME,
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD, // Will be hashed automatically
        isSuperAdmin: true        // ✅ Mark as Super Admin
      });

      try {
        await admin.save();
        console.log('✅ Super Admin created successfully');
      } catch (err) {
        if (err.code === 11000) {
          console.log('❌ Admin with this email already exists (duplicate key error).');
        } else {
          console.error('❌ Error saving admin:', err);
        }
      }
    }
  } catch (err) {
    console.error('❌ MongoDB connection error:', err);
  } finally {
    mongoose.disconnect();
  }
}

createAdmin();