const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();
const Category = require("../models/Category");
const Blog = require("../models/Blog");
const verifyToken = require("../middleware/authMiddleware");

// POST /api/categories/create → Admin only
router.post("/create", verifyToken, async (req, res) => {
  const { name } = req.body;

  if (!name)
    return res.status(400).json({ message: "Category name is required" });

  try {
    const existing = await Category.findOne({ name });
    if (existing)
      return res.status(409).json({ message: "Category already exists" });

    const category = new Category({ name });
    await category.save();

    res.status(201).json({ message: "Category created", category });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error creating category", error: err.message });
  }
});

// GET /api/categories → Get all categories (public)
router.get("/", async (req, res) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    res.json(categories);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching categories", error: err.message });
  }
});

// DELETE /api/categories/:id → Admin only
// Ensure category is not linked to any blog before deletion
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const categoryId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(categoryId)) {
      return res.status(400).json({ message: "Invalid category ID" });
    }

    const isUsed = await Blog.exists({ category: categoryId });
    if (isUsed) {
      return res.status(400).json({
        message: "Cannot delete: This category is linked to one or more blogs.",
      });
    }

    const deletedCategory = await Category.findByIdAndDelete(categoryId);

    if (!deletedCategory) {
      return res.status(404).json({ message: "Category not found" });
    }

    res.status(200).json({ message: "Category deleted successfully" });
  } catch (err) {
    console.error("🔥 Error deleting category:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
