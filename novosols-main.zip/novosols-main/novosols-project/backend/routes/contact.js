const express = require("express");
const router = express.Router();
const { handleContactForm,getAllContacts } = require("../controllers/contactController");
const verifyToken = require("../middleware/authMiddleware");

router.post("/", handleContactForm);
router.get("/", verifyToken, getAllContacts);

module.exports = router;
