const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Admin = require("../models/Admin");
const verifyToken = require("../middleware/authMiddleware");

// auth/me route to check if user is logged in
router.get("/me", verifyToken, (req, res) => {
  // If token is valid, send back user info (admin) details
  res.json({ loggedIn: true, admin: req.admin });
});

// Route: POST /api/login
// Logs in the admin and sets JWT in HTTP-only cookie
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(401).json({ message: "Admin not found" });

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch)
      return res.status(401).json({ message: "Incorrect password" });

    const token = jwt.sign(
      { id: admin._id, email: admin.email, isSuperAdmin: admin.isSuperAdmin },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res
      .cookie("token", token, {
        httpOnly: true,
        secure: false, // set to true in production with HTTPS
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000, // 1 day
      })
      .json({
        message: "Login successful",
        admin: {
          name: admin.name,
          email: admin.email,
          isSuperAdmin: admin.isSuperAdmin,
        },
      });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// Route: GET /api/auth/logout
// Logs out the admin by clearing the JWT cookie
router.get("/logout", (req, res) => {
  res.clearCookie("token", {
    httpOnly: true,
    sameSite: "lax",
    secure: false, // set true in production
  });
  res.status(200).json({ message: "Logged out successfully" });
});

// Route: POST /api/auth/admins/create
// Creates a new admin (protected)
router.post("/admins/create", verifyToken, async (req, res) => {
  const { name, email, password, isSuperAdmin = false } = req.body;

  try {
    const existing = await Admin.findOne({ email });
    if (existing)
      return res.status(400).json({ message: "Admin already exists" });

    const newAdmin = new Admin({ name, email, password, isSuperAdmin }); // Auto-hashed
    await newAdmin.save();

    res.status(201).json({
      message: "Admin created successfully",
      admin: { name, email, isSuperAdmin },
    });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// Route: DELETE /api/auth/admins/:id
// Deletes an admin (protected, Super Admin only)
router.delete("/admins/:id", verifyToken, async (req, res) => {
  const { id } = req.params;

  // Only Super Admins can delete admins
  if (!req.admin.isSuperAdmin) {
    return res.status(403).json({ message: "Access denied. Only Super Admins can delete admins." });
  }

  try {
    const adminToDelete = await Admin.findById(id);

    if (!adminToDelete) {
      return res.status(404).json({ message: "Admin not found" });
    }

    // Prevent Super Admin from deleting themselves
    if (adminToDelete._id.toString() === req.admin.id) {
      return res.status(400).json({ message: "You cannot delete your own account." });
    }

    await Admin.findByIdAndDelete(id);

    res.status(200).json({ message: "Admin deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// Fetch all admins (protected)
router.get("/admins", verifyToken, async (req, res) => {
  try {
    const admins = await Admin.find({}, { password: 0, __v: 0 }); // exclude password & __v
    res.status(200).json(admins);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
