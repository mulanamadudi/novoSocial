const express = require("express");
const router = express.Router();
const Blog = require("../models/Blog");
const Admin = require("../models/Admin");
const verifyToken = require("../middleware/authMiddleware");

// Utility: Calculate estimated read time
const calculateReadTime = (content) => {
  const words = content.trim().split(/\s+/).length;
  return Math.ceil(words / 200); // 200 words per minute
};

// ====================
// Private Blog Routes
// ====================

// POST /api/blogs/create → Create blog (admin only)
// // router.post('/create', verifyToken, async (req, res) => {
//   const { title, content, category, tags, thumbnail } = req.body;

//   try {
//     const readTime = calculateReadTime(content);

//     const blog = new Blog({
//       title,
//       content,
//       category,
//       tags,
//       thumbnail,
//       readTime,
//       author: req.admin.id, // from token
//     });

//     await blog.save();
//     res.status(201).json({ message: 'Blog created', blog });
//   } catch (err) {
//     res.status(500).json({ message: 'Error creating blog', error: err.message });
//   }
// });

// POST /api/blogs/create → Create blog (admin only)
router.post("/create", verifyToken, async (req, res) => {
  const { title, content, category, tags, thumbnail } = req.body;

  try {
    // Check if the category exists
    const categoryExists = await require("../models/Category").findById(
      category
    );
    if (!categoryExists) {
      return res.status(400).json({ message: "Invalid category" });
    }

    const readTime = calculateReadTime(content);

    const blog = new Blog({
      title,
      content,
      category, // this is now a valid ObjectId
      tags,
      thumbnail,
      readTime,
      author: req.admin.id, // from token
    });

    await blog.save();
    res.status(201).json({ message: "Blog created", blog });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error creating blog", error: err.message });
  }
});

// PUT /api/blogs/:id → Update blog (admin only)
router.put("/:id", verifyToken, async (req, res) => {
  const { title, content, category, tags, thumbnail } = req.body;

  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "Blog not found" });

    // Optional: Only allow creator to update
    // if (blog.author.toString() !== req.admin.id) return res.status(403).json({ message: 'Not allowed' });

    blog.title = title || blog.title;
    blog.content = content || blog.content;
    blog.category = category || blog.category;
    blog.tags = tags || blog.tags;
    blog.thumbnail = thumbnail || blog.thumbnail;
    blog.readTime = calculateReadTime(content || blog.content);
    blog.updatedAt = Date.now();

    await blog.save();
    res.json({ message: "Blog updated", blog });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error updating blog", error: err.message });
  }
});

// DELETE /api/blogs/:id → Delete blog (admin only)
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) return res.status(404).json({ message: "Blog not found" });

    await Blog.findByIdAndDelete(req.params.id);
    res.json({ message: "Blog deleted" });
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error deleting blog", error: err.message });
  }
});

// ====================
// Public Blog Routes
// ====================

// GET /api/blogs → List all blogs with optional filters
router.get("/", async (req, res) => {
  const { category, tags, sort, q } = req.query;

  const filter = {};

  if (q) {
    filter.title = { $regex: q, $options: "i" }; // search by title
  }

  if (category) filter.category = category;
  if (tags) filter.tags = { $in: tags.split(",") };

  // let query = Blog.find(filter).populate('author', 'name email');
  let query = Blog.find(filter)
    .populate("author", "name email")
    .populate("category", "name");

  if (sort === "latest") query = query.sort({ createdAt: -1 });
  else if (sort === "oldest") query = query.sort({ createdAt: 1 });

  try {
    const blogs = await query.exec();
    res.json(blogs);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching blogs", error: err.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id)
      .populate("author", "name email")
      .populate("category", "name");

    if (!blog) return res.status(404).json({ message: "Blog not found" });
    res.json(blog);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching blog", error: err.message });
  }
});

// GET /api/blogs/category/:cat → Filter by category
router.get("/category/:cat", async (req, res) => {
  try {
    const blogs = await Blog.find({ category: req.params.cat }).populate(
      "author",
      "name email"
    );
    res.json(blogs);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error filtering category", error: err.message });
  }
});

router.get("/slug/:slug", async (req, res) => {
  try {
    const blog = await Blog.findOne({ slug: req.params.slug })
      .populate("author", "name email")
      .populate("category", "name");

    if (!blog) return res.status(404).json({ message: "Blog not found" });
    res.json(blog);
  } catch (err) {
    res.status(500).json({ message: "Error fetching blog", error: err.message });
  }
});


module.exports = router;
