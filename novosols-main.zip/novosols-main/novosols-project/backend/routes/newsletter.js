const express = require("express");
const verifyToken = require("../middleware/authMiddleware");
const Newsletter = require("../models/Newsletter")
const router = express.Router();
const {
  subscribeNewsletter,
  confirmSubscription,
  unsubscribeNewsletter,
  getNewsletterStatus,
} = require("../controllers/newsletterController");

router.post("/subscribe", subscribeNewsletter);         // POST /api/newsletter/subscribe
router.get("/confirm", confirmSubscription);    
router.get("/unsubscribe", unsubscribeNewsletter);        // GET  /api/newsletter/confirm?token=abc123
router.get("/status", getNewsletterStatus); // GET /api/newsletter/status

router.get("/", verifyToken, async (req, res) => {
  try {
    const subscribers = await Newsletter.find({}, { __v: 0 });
    res.status(200).json(subscribers);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});


module.exports = router;
