const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');

// Load env variables
dotenv.config();

// App instance
const app = express();

// Middleware
// app.use(cors());
app.use(cors({
  origin: 'http://82.29.164.121', // Frontend origin
  credentials: true               // Allow cookies if needed
}));


// app.use(express.json());
app.use(express.json({ limit: '5mb' }));


// Cookie parser
const cookieParser = require('cookie-parser');
app.use(cookieParser());

// Static file serving for uploads
app.use('/uploads', express.static(path.join(__dirname, '../frontend/public/uploads')));

// Default route
app.get('/', (req, res) => {
  res.send('Backend is working!');
});

// Routes
const authRoutes = require('./routes/auth');
const blogRoutes = require('./routes/blog');
const contactRoutes = require("./routes/contact");
const newsletterRoutes = require("./routes/newsletter");
const dashboardRoutes = require("./routes/dashboardRoutes");
const uploadRoute = require('./routes/upload');
const categoryRoutes = require('./routes/category');

// app.use('/api/auth', authRoutes);
// app.use('/api/blogs', blogRoutes);
// app.use("/api/contact", contactRoutes);
// app.use("/api/newsletter", newsletterRoutes);
// app.use("/api/dashboard", dashboardRoutes);
// app.use('/api/upload', uploadRoute);
// app.use('/api/categories', categoryRoutes);

app.use('/auth', authRoutes);
app.use('/blogs', blogRoutes);
app.use("/contact", contactRoutes);
app.use("/newsletter", newsletterRoutes);
app.use("/dashboard", dashboardRoutes);
app.use('/upload', uploadRoute);
app.use('/categories', categoryRoutes);


mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(async () => {
  console.log('✅ MongoDB connected');
})
.catch((err) => {
  console.error('❌ MongoDB connection error:', err);
});


// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
